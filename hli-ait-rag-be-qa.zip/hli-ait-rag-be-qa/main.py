import os
import sys
from os import path

work_dir = path.dirname(path.abspath(__file__))

from fastapi import FastAPI
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.staticfiles import StaticFiles
from starlette.exceptions import HTTPException
import uvicorn
sys.path.append(os.path.join(os.path.dirname(__file__),'src'))

# print('os.path.dirname(__file__)',os.path.dirname(__file__))
# print('sys.path',sys.path)
from src.common.logging.logger import LOGGER

from src.apps.orchestra_router import router

def get_fastapi_app():
    app = FastAPI(
        title="Hanwhalife AI STS Orchestrator",
        description="Orchestrator",
        version="v1",
        docs_url=None
    )

    # CORS 추가
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=["*"],
    )

    # router 추가
    app.include_router(router)

    # Swagger 파일 등록 (운영 때 삭제 예정)
    path_to_static = path.join(work_dir, "src/resources/static")
    app.mount("/static", StaticFiles(directory=path_to_static), name="static")

    return app


def getApp() -> FastAPI:
    app = get_fastapi_app()

    @app.on_event("startup")
    async def startup_event():
        global startup_complete
        startup_complete = True

    @app.get("/health/startup")
    async def startup():
        if startup_complete:
            return JSONResponse(status_code=200, content={"status": "started"})
        else:
            return JSONResponse(status_code=503, content={"status": "starting"})

    @app.get("/health/readiness")
    async def readiness():
        return JSONResponse(status_code=200, content={"status": "ready"})

    @app.get("/health/liveness")
    async def liveness():
        return JSONResponse(status_code=200, content={"status": "alive"})


    @app.get("/docs", include_in_schema=False)
    async def custom_swagger_ui_html():
        return get_swagger_ui_html(
            openapi_url=app.openapi_url,
            title="Embedding Test",
            oauth2_redirect_url=app.swagger_ui_oauth2_redirect_url,
            swagger_js_url="/static/swagger-ui-bundle.js",
            swagger_css_url="/static/swagger-ui.css",
            swagger_favicon_url="/static/favicon-32x32.png",
        )

    return app


if __name__ == "__main__":
    # Set log_path
    #os.environ["CLUSTER_PROFILE"] = "dev"
    app_env = os.environ["CLUSTER_PROFILE"]
    if app_env in ["dev", "qa", "prd"]:
        #log_path = work_dir + f"/resources/config/{app_env}/log.ini"
        log_path = work_dir + f"/src/resources/config/{app_env}/log.ini"
    else:
        raise ValueError(f"Invalid CLUSTER_PROFILE value: {app_env}")

    # App serving
    application = getApp()
    uvicorn.run("main:getApp", host="0.0.0.0", port=8080, log_config=log_path, workers=16, reload=False)
