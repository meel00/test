import os
from azure.identity import ManagedIdentityCredential
from redis import Redis

from src.common.property.environment import env


client_id = env.get("REDIS_CLIENT_ID")
host = env.get("REDIS_HOST")
port = env.get("REDIS_PORT")
username = env.get("REDIS_USERNAME")
scope = env.get("REDIS_TOKEN_SCOPE")

# Azure Entra 인증을 활용한 Redis 연결
credential = ManagedIdentityCredential(client_id = client_id)
redis_conn = Redis(
    host = host,
    port = port,
    ssl = True,
    username = username,
    password = credential.get_token(scope).token
)

# 토큰이 1시간에 한 번씩 갱신되므로 1시간이 지나기 전에 Redis connection 초기화 필요
# Data Get/Set 수행 시 TTL 값 세팅하여 데이터가 해당 시간이 지나면 사라지도록 설정