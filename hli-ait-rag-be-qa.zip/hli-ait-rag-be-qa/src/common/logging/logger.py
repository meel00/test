import logging

"""
@ FileName : logger
@ Description : LOGGER 객체를 생성하여 하나의 프로젝트에서 동일한 LOGGER를 사용할 수 있도록 한다.
@ Usage
    from src.common.logging.logger import LOGGER
    LOGGER.debug("xxx")
"""

# create logger
LOGGER = logging.getLogger("root")
