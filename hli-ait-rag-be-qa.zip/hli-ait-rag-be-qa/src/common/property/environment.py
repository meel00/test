import os
from os import path
from dotenv import load_dotenv

"""
@ FileName : environment
@ Description : .env 파일에 저장된 설정 값을 로딩하여 응용 소스에서 활용할 수 있도록 한다.
                설정 파일 위치는 src/resources/config/[dev, qa, prd]/app.env이다.
                각 서버의 CLUSTER_PROFILE 환경 변수 값에 따라 로딩할 파일을 결정한다. (export CLUSTER_PROFILE=dev/qa/prd)
@ Usage
    from src.common.property.environment import env
    env.get("KEY")
"""

work_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class Environment:
    def __init__(self):
        app_env = os.environ["CLUSTER_PROFILE"]
        if app_env in ["dev", "qa", "prd"]:
            env_path = work_dir + f"/resources/config/{app_env}/app.env"
        else:
            raise ValueError(f"Invalid CLUSTER_PROFILE value: {app_env}")

        load_dotenv(env_path)

    @staticmethod
    def get(key):
        return os.environ[key]

env = Environment()