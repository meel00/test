import random
from typing import List,Dict
from typing import Optional

def ratebasedqna(request_message):

    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    user_query = request_message.user_query
    #==================================
    # 기사 데이터 "제목, 본문, 출처" 형식으로 저장
    # 기사 데이터 "제목, 본문, 출처" 형식으로 저장
    articles = [
            {
                "llm_response": "20%",
                "sources": [
                {
                    "source_name": "한화생명 시그니처 암치료비보장보험 상품 안내서",
                    "details": "Page 3"
                }
                ]
            },
            {
                "llm_response": "30%",
                "sources": [
                {
                    "source_name": "보험설명서",
                    "details": "Page 3-8에서 발췌한 한화생명 시그니처 암치료비보험에 대한 정보"
                }
                ]
            },
            {
                "llm_response": "40%",
                "sources": [
                {
                    "source_name": "상품설명서",
                    "details": "Page 2"
                },
                ]
            },
            {
                "llm_response": "50%",
                "sources": [
                {
                    "source_name": "상품설명서",
                    "details": "가입 상품 및 보장내용 요약 (한화생명 시그니처 암치료비보험 제안서, Pages 3-5)"
                },
                ]
            }
        ]

        # 5개의 랜덤 기사를 선택하는 함수
    def get_random_articles(count: int = 1) -> List[Dict]:
        news_= [item["llm_response"] for item in articles]

        return random.sample(news_, count)
        #return random.sample(articles, count)

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "llm_response" : get_random_articles(), 
            }
    }


def ratebasedqna_dummy(request_message):

    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    user_query = request_message.user_query
    #==================================
    # 기사 데이터 "제목, 본문, 출처" 형식으로 저장
    # 기사 데이터 "제목, 본문, 출처" 형식으로 저장
    articles = [
            {
                "llm_response": "20%",
                "sources": [
                {
                    "source_name": "한화생명 시그니처 암치료비보장보험 상품 안내서",
                    "details": "Page 3"
                }
                ]
            },
            {
                "llm_response": "30%",
                "sources": [
                {
                    "source_name": "보험설명서",
                    "details": "Page 3-8에서 발췌한 한화생명 시그니처 암치료비보험에 대한 정보"
                }
                ]
            },
            {
                "llm_response": "40%",
                "sources": [
                {
                    "source_name": "상품설명서",
                    "details": "Page 2"
                },
                ]
            },
            {
                "llm_response": "50%",
                "sources": [
                {
                    "source_name": "상품설명서",
                    "details": "가입 상품 및 보장내용 요약 (한화생명 시그니처 암치료비보험 제안서, Pages 3-5)"
                },
                ]
            }
        ]

        # 5개의 랜덤 기사를 선택하는 함수
    def get_random_articles(count: int = 1) -> List[Dict]:
        news_= [item["llm_response"] for item in articles]

        return random.sample(news_, count)
        #return random.sample(articles, count)

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "llm_response" : get_random_articles(), 
            }
    }