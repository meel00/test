# 시뮬레이션 실전 대화 , 실전 대화 전환 3TYPE

# FASTAPI 반환구조

# 1. 가상 대화 생성 (주어진 프롬프트로) == ###FULL 화법 JSON 반환###

# 2. FP가 말을 한다........

# 3. 스테이지 정보와 , FP가 말한것이 문자로 넘어온다.

# 4. JUDGE 프롬프트에 스테이지 정보와 ,FP 발화문이 넘어가서 == 스테이지 클리어를 체크한다
 
# 5. 스테이지 클리어 반환한다. == ###스테이지 클리어 JSON 반환###

#    반복......

# 6. 마지막 단계 완료시 == ###피드백 JSON반환###

import random
from typing import List,Dict
from typing import Optional
from src.utils.aoai_helper import AOAIHelper
from src.utils.db_helper import *
from src.utils.db_query import *
from src.utils.elasticsearch_query import *
from src.utils.util import *
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from src.utils import pdf_table,prompts
from langchain.schema import SystemMessage,HumanMessage
from src.common.logging.logger import LOGGER
import os
import json
import time

def simulationvirtualtalk(fp_id,menu_id,stage):
    # 기사 데이터 "제목, 본문, 출처" 형식으로 저장
    # 기사 데이터 "제목, 본문, 출처" 형식으로 저장
    articles = [
            {
                "llm_message": "고객님, 현재 건강에 대한 관심이 높아지고 있는 만큼 암 보험은 꼭 필요하다고 할 수 있습니다. 고객님의 프로필을 확인해보니, 34세 남성 직장인이시고 자녀가 두 명 있는 가장으로서 건강에 더욱 신경 쓰고 계시군요. 이를 고려하여 한화생명의 시그니처 암치료비보장보험을 추천드립니다.\n\n이 보험은 장기적으로 암 치료에 필요한 자금을 보장받으며, 보험료 부담을 줄일 수 있는 해약환급금 미지급형 상품입니다. 특히 90세까지 보장받으실 수 있어 노후까지 대비가 가능합니다. 주계약으로 가입하실 경우 월 1,495원의 보험료로 기본 보장을 받을 수 있습니다.\n\n암 주요 치료보장S 특약을 통해서 고객님께서 가장 우려하시는 종합병원 및 상급종합병원 암 치료비를 지원받을 수 있고, 최대 1억원까지 치료를 보장받으실 수 있습니다. 이 외에도 여러 특약들이 있어 고객님의 필요에 맞게 구성할 수 있습니다. 예를 들어, 연간 암주요치료비가 500만원 이상일 경우 1억원까지 보장되며, 상급종합병원 통원치료 시에는 50만원씩 보장합니다.\n\n고객님께서 관심이 가실만한 점은, 주계약뿐만 아니라 다양한 특약을 추가할 수 있다는 점입니다. 암 주요 치료비 지원 특약이나 통원치료비 특약을 통해 더욱 폭넓은 보장을 받으실 수 있습니다. 중요한 것은 언제 또 어떤 일이 발생할지 모르는 상황에 대비하는 것입니다.\n\n지금 바로 가입하셔서 든든한 보장을 받으시는 것도 좋을 듯합니다. 궁금한 점이나 추가로 궁금하신 사항이 있으시면 언제든지 연락 주시기 바랍니다.",
                "sources": [
                {
                    "source_name": "한화생명 시그니처 암치료비보장보험 상품 안내서",
                    "details": "해약환급금 미지급형 상품으로 90세까지의 장기 보장을 제공합니다. 보험료는 가입자의 나이, 조건 등에 따라 달라질 수 있으며, 보장금액 및 특약 선택에 따라 변경됩니다."
                }
                ]
            },
            {
                "llm_message": "안녕하세요 고객님, 건강을 중요시하시는 고객님을 위해 암 보험 상품을 소개해드리려고 합니다. 이 상품은 한화생명의 시그니처 암치료비보장보험(무배당)으로, 고객님의 필요에 맞춰 다양한 보장을 제공하고 있습니다.\n\n이 보험은 90세 만기, 5년 납입 조건으로 설정되어 있으며, 해약환급금 미지급형을 통해 보험료 부담을 덜 수 있습니다. 주계약의 경우 월 1,495원으로 50만원까지 보장받으실 수 있으며, 필요에 따라 여러 특약을 선택하실 수 있습니다.\n\n특히 중요한 특약으로 '암 주요 치료보장S특약'이 있습니다. 이 특약을 통해서 고객님은 기타피부암이나 갑상선암을 제외한 암 치료 시 500만원까지 보장받을 수 있습니다. 추가로 '암주요치료비 지원S특약'은 종합병원에서 암 치료 시 연간 치료비가 5백만원 이상일 경우 최대 1억원까지 지원합니다.\n\n또한, 통원치료에 대한 특약도 마련되어 있어, 상급종합병원에서 암 직접 치료를 받을 경우 연간 30회 한도로 최대 50만원을 1회당 보장합니다. 이러한 다양한 특약들을 통해 고객님의 건강을 보다 폭넓게 보호할 수 있습니다.\n\n고객님, 예상치 못한 상황에 대비해 보장을 강화하시는 것을 고려해보시는 것이 어떨까요? 언제라도 추가 질문이 있거나 더 자세한 설명이 필요하시면 편하게 연락 주세요.",
                "sources": [
                {
                    "source_name": "보험설명서",
                    "details": "Page 3-8에서 발췌한 한화생명 시그니처 암치료비보험에 대한 정보"
                }
                ]
            },
            {
                "llm_message": "안녕하세요 고객님. 오늘은 고객님과 고객님의 가족 즉 두 자녀를 고려하여 최적의 암 보험 상품을 소개해드리려고 합니다. 건강을 중시하시는 만큼 암보험의 중요성과 필요성을 느끼고 계실 텐데요.\n\n먼저, 이 상품은 한화생명의 '시그니처 암치료비보장보험'입니다. 고객님과 같은 34세 직장인 남성을 위한 맞춤형 상품입니다. 이 보험은 보험료 부담을 최소화하면서도 암 치료에 필요한 다양한 보장을 제공하는 해약환급금이 없는 형태로 설계되어 있습니다.\n\n기본적으로 50만 원의 가입금액을 가진 주계약을 통해 90세까지 보장받으실 수 있습니다. 월 보험료는 1,495원으로 매우 합리적입니다. 특약을 추가로 선택하여, 고객님의 필요에 맞춘 보장을 강화할 수도 있습니다. 예를 들어, 주요 암 치료보장 특약을 통해 기타피부암과 갑상선암을 제외한 암 진단시 최대 500만 원까지 지원받을 수 있습니다.\n\n종합병원에서의 암 주요 치료비를 연간 1억 원까지 보장받을 수 있는 특약도 준비되어 있습니다. 또한, 상급종합병원에서의 통원치료 보장 특약으로 한 회당 50만 원씩 연간 30회까지 지원되는 항목도 있습니다.\n\n고객님, 암 보험은 예상치 못한 상황에 대비할 수 있는 중요한 자산입니다. 특히 두 자녀가 있는 고객님 가정에게 암 보험의 필요성은 더욱 클 수 있습니다. 지금 바로 가입하셔서 든든한 보장을 받으시는 것은 어떨까요? 질문이나 추가적인 설명이 필요하신 경우 언제든지 연락해 주세요.",
                "sources": [
                {
                    "source_name": "상품설명서",
                    "details": "Page 2"
                },
                {
                    "source_name": "가입금액 및 보험료",
                    "details": "Page 3"
                }
                ]
            },
            {
                "llm_message": "안녕하세요, 고객님. 건강을 중요하게 여기신다는 말씀에 귀를 기울이면서, 암 치료비 보험에 대해 말씀드리고 싶습니다. 한화생명의 시그니처 암치료비보험(무배당)은 고객님의 필요에 꼭 맞는 상품이라고 자신 있게 말씀드릴 수 있습니다.\n\n이 상품은 고객님과 같은 34세 직장인 남성, 그리고 가족을 중요시하는 분들께 특히 유리한 상품입니다. 해약환급금 미지급형을 통해 보험료 부담을 효과적으로 줄이면서도 필수적인 암 치료 보장을 받을 수 있습니다. 주계약으로 50만원의 가입금액에 월 보험료가 매우 합리적입니다. 게다가 다양한 선택 특약을 통해 최대 1억원의 암 치료비까지 보장받을 수 있어 혹시 모를 의료비 부담에서 안심하실 수 있습니다.\n\n고객님께서 주목하실 만한 특약을 소개해드릴게요. 암 주요 치료보장 특약을 통해, 기타피부암과 갑상선암을 제외한 암을 진단받고 치료하실 때 최대 500만원까지 보장받을 수 있습니다. 또한, 암 주요 치료비 지원 S 특약을 통해 종합병원에서의 암 치료비를 연간 최대 1억원까지 보장해드립니다. 상급종합병원에서의 암 직접 치료 동원 S 특약을 가입하시면, 치료 시 1회당 50만원씩 연간 최대 30회 보장도 가능합니다.\n\n고객님, 이러한 보장은 가족과 함께할 소중한 미래를 지키는 데에 중요한 역할을 할 것입니다. 건강을 최우선으로 생각하신다면 이번 기회에 든든한 보장을 마련해 보시는 건 어떨까요? 더 궁금한 점이나 추가로 설명드릴 부분이 있다면 언제든지 문의해 주세요.",
                "sources": [
                {
                    "source_name": "상품설명서",
                    "details": "가입 상품 및 보장내용 요약 (한화생명 시그니처 암치료비보험 제안서, Pages 3-5)"
                },
                {
                    "source_name": "필수 안내사항",
                    "details": "필수 유의사항 (한화생명 시그니처 암치료비보험 제안서, Page 2)"
                }
                ]
            }
        ]

        # 5개의 랜덤 기사를 선택하는 함수
    def get_random_articles(count: int = 1) -> List[Dict]:
        news_= [item["llm_response"] for item in articles]

        return random.sample(news_, count)
        #return random.sample(articles, count)

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "stage_check" : True,
            "llm_response" : get_random_articles(), 
            }
    }

    # return {
    #     "isSuccess" : True,
    #     "code" :"200",
    #     "message": "조회성공",
    #     "data" : {
    #         "response_message":  get_random_articles()
    #     }
    # }

def stage_judge(fp_id,menu_id,stage,user_query):

    ###########################평가자 시작###################################
    aoai_judge = AOAIHelper()
    data = aoai_judge.get_prompt_by_id("008_1")
    system_Message =SystemMessage(content=json.dumps(data["system_template"]['content'],ensure_ascii=False))
    LOGGER.debug(system_Message)

    userPrompt = data["human_template"]

    stageNo = "stage" + stage
    userPrompt = userPrompt[stageNo]


    llmQuery = "레디스에서 가져올거야"

    if stage == "4" :
        llmQuery = " 본 보험의 장점에 대해 말씀해 주세요"
        userPrompt['질문'] = llmQuery
        
    userPrompt['대화'] = user_query

    human_Message =HumanMessage(content=json.dumps(userPrompt,ensure_ascii=False))
    LOGGER.debug(human_Message)
    message = [system_Message,human_Message]
    
    response = aoai_judge.get_generate_text_response(message)

    LOGGER.debug(response)
    stage_check = response
    ############################평가자 끝###########################

    ###########################답변자 시작###################################
    aoai = AOAIHelper()
    data = aoai.get_prompt_by_id("008")
    system_Message =SystemMessage(content=json.dumps(data["system_template"]['content'],ensure_ascii=False))
    LOGGER.debug(system_Message)

    userPrompt = data["human_template"]

    stageNo = "stage" + stage
    userPrompt = userPrompt[stageNo]


    llmQuery = "레디스에서 가져올거야"

    userPrompt['대화'] = user_query

    if stage == "4" :
        llmQuery = " 본 보험의 장점에 대해 말씀해 주세요, 금리는 얼마인가요?"
        userPrompt['prompt_history'] = llmQuery
        domain = f"""
        **상품특징** : 신규 보험이 우리아이 저축보험은 년 3.4%에 특별금리 0.6%를 가산하여 지급할 수 있다.  가입연령은 만14세 이상 되어야 한다. 중도해지시에는 10년이 지나야 원급손실이 없다.
               10년이 지나면 면세이다
        """

        # 템플릿에서 변수 치환
        context_text = f"""
                        domain: {domain},
                        """

        userPrompt['context'] = context_text

    human_Message =HumanMessage(content=json.dumps(userPrompt,ensure_ascii=False))
    LOGGER.debug(human_Message)
    message = [system_Message,human_Message]
    
    response = aoai.get_generate_text_response(message)

    LOGGER.debug(response)

    llm_response = response

    if stage_check == "false":
        llm_response= ""


    ###########################답변자 끝###################################

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "stage_check" : stage_check ,
            "llm_response": llm_response
            }
    }
    
def stage_feedback(fp_id,menu_id,stage,user_query):

    aoai = AOAIHelper()
    data = aoai.get_prompt_by_id("008_2")
    system_Message =SystemMessage(content=json.dumps(data["system_template"]['content'],ensure_ascii=False))
    LOGGER.debug(system_Message)

    userPrompt = data["human_template"]

    redis_history = """
    상품정보 : 신규보험이 우리아이 저축보험은 년 3.4%에 특별금리 0.6%를 가산하여 지급할 수 있다.  가입연령은 만14세 이상 되어야 한다. 중도해지시에는 10년이 지나야 원급손실이 없다.
               10년이 지나면 면세이다.  
    FP : 안녕하세요 고객님
    LLM : 안녕하세요~
    FP : 요즘 날씨가 아주 좋은데 단풍 구경 좀 하셨나요? 여의도가 노랗고 빨갛게 단풍이 좋아서 산책하기 좋습니다.
    LLM : 아 아직 못갔는데 한번 가보아야겠네요. 정보 고맙습니다.
    FP : 요즘 연말이라 보너스도 나오실텐데 ㅎㅎ 자녀를 위한 저축보험 하나 추천 드릴려고 합니다. 한시적으로 연말까지만 파는건데 특별히 고객님께 연락드리는 겁니다.. ㅎㅎ 이게 한도가 있어서요.
         장점을 간단하게 말씀드리면 중도해지시 전혀 원금의 손해가 없고. 변동 금리형이라 금리가 올라도 환급금이 올라갑니다. 그리고 10년이상 보유하시면 무려 세금이 없어요..더 많지만 시간관계상
         궁금한점이 있으시면 제가 답변해 드릴께요
    LLM : 아 그럼 가입 연령의 제한이 있나요 마침 아이 보험하나 찾고 있었는데
    FP : 아 14세 이상이면 가능합니다.
    LLM : 아 가능하군요.. 그러면 지금 금리가 얼마인가요?
    FP : 년 3.5% 에 특별 금리 0.7 더해 드리면 4.3% 가 됩니다. 파격적이죠
    LLM : 오  좋습니다. 집에 가서 한번 의논해 보고 연락 드릴께요.
    FP : 네 고객님. 궁금하신 점이 있으시면 시간 구애받지 마시고 연락 주세요. 고객님의 궁금증을 해소 해 드리겠습니다.
    LLM: 네 수고하세요.
     """

    userPrompt['content']['prompt_history'] = redis_history

    human_Message =HumanMessage(content=json.dumps(userPrompt,ensure_ascii=False))
    LOGGER.debug(human_Message)
    message = [system_Message,human_Message]
    
    response = aoai.get_generate_text_response(message)

    LOGGER.debug(response)
    llm_response = response

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "stage_check" : "true" ,
            "llm_response": llm_response
            }
    }

def simulationvirtualtalk_stage(request_message) -> List[Dict]:
     # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    age = request_message.age
    gender = request_message.gender
    career_field = request_message.career_field
    product_name = request_message.product_name
    product_tag = request_message.product_tag
    news_id = request_message.news_id
    stage = request_message.stage
    user_query = request_message.user_query
    #==================================

    if stage == "0":
        return simulationvirtualtalk(fp_id,menu_id,stage)
    elif stage == "1":
        return stage_judge(fp_id,menu_id,stage,user_query)
    elif stage == "2":
        return stage_judge(fp_id,menu_id,stage,user_query)
    elif stage == "3":
        return stage_judge(fp_id,menu_id,stage,user_query)
    elif stage == "39":
        print("질의 시작")
    elif stage == "4":
        return stage_judge(fp_id,menu_id,stage,user_query)
    elif stage == "49":
        print("질의 끝")
    elif stage == "5":
         return stage_judge(fp_id,menu_id,stage,user_query)
    elif stage == "99":
        return stage_feedback(fp_id,menu_id,stage,user_query)


######################## 이하 더미용  ####################################
def simulationvirtualtalk_stage_dummy(request_message) -> List[Dict]:
     # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    age = request_message.age
    gender = request_message.gender
    career_field = request_message.career_field
    product_name = request_message.product_name
    product_tag = request_message.product_tag
    news_id = request_message.news_id
    stage = request_message.stage
    user_query = request_message.user_query
    #==================================

    if stage == "0":
        return simulationvirtualtalk_dummy(fp_id,menu_id,stage)
    else:
        #마지막 턴인 경우 99
        if stage=="99":
            return stage_feedback_dummy(fp_id,menu_id,stage,user_query)
        else:
            return stage_judge_dummy(fp_id,menu_id,stage,user_query)

def simulationvirtualtalk_dummy(fp_id,menu_id,stage):
    # 기사 데이터 "제목, 본문, 출처" 형식으로 저장
    # 기사 데이터 "제목, 본문, 출처" 형식으로 저장
    articles = [
            {
                "llm_message": "고객님, 현재 건강에 대한 관심이 높아지고 있는 만큼 암 보험은 꼭 필요하다고 할 수 있습니다. 고객님의 프로필을 확인해보니, 34세 남성 직장인이시고 자녀가 두 명 있는 가장으로서 건강에 더욱 신경 쓰고 계시군요. 이를 고려하여 한화생명의 시그니처 암치료비보장보험을 추천드립니다.\n\n이 보험은 장기적으로 암 치료에 필요한 자금을 보장받으며, 보험료 부담을 줄일 수 있는 해약환급금 미지급형 상품입니다. 특히 90세까지 보장받으실 수 있어 노후까지 대비가 가능합니다. 주계약으로 가입하실 경우 월 1,495원의 보험료로 기본 보장을 받을 수 있습니다.\n\n암 주요 치료보장S 특약을 통해서 고객님께서 가장 우려하시는 종합병원 및 상급종합병원 암 치료비를 지원받을 수 있고, 최대 1억원까지 치료를 보장받으실 수 있습니다. 이 외에도 여러 특약들이 있어 고객님의 필요에 맞게 구성할 수 있습니다. 예를 들어, 연간 암주요치료비가 500만원 이상일 경우 1억원까지 보장되며, 상급종합병원 통원치료 시에는 50만원씩 보장합니다.\n\n고객님께서 관심이 가실만한 점은, 주계약뿐만 아니라 다양한 특약을 추가할 수 있다는 점입니다. 암 주요 치료비 지원 특약이나 통원치료비 특약을 통해 더욱 폭넓은 보장을 받으실 수 있습니다. 중요한 것은 언제 또 어떤 일이 발생할지 모르는 상황에 대비하는 것입니다.\n\n지금 바로 가입하셔서 든든한 보장을 받으시는 것도 좋을 듯합니다. 궁금한 점이나 추가로 궁금하신 사항이 있으시면 언제든지 연락 주시기 바랍니다.",
                "sources": [
                {
                    "source_name": "한화생명 시그니처 암치료비보장보험 상품 안내서",
                    "details": "해약환급금 미지급형 상품으로 90세까지의 장기 보장을 제공합니다. 보험료는 가입자의 나이, 조건 등에 따라 달라질 수 있으며, 보장금액 및 특약 선택에 따라 변경됩니다."
                }
                ]
            },
            {
                "llm_message": "안녕하세요 고객님, 건강을 중요시하시는 고객님을 위해 암 보험 상품을 소개해드리려고 합니다. 이 상품은 한화생명의 시그니처 암치료비보장보험(무배당)으로, 고객님의 필요에 맞춰 다양한 보장을 제공하고 있습니다.\n\n이 보험은 90세 만기, 5년 납입 조건으로 설정되어 있으며, 해약환급금 미지급형을 통해 보험료 부담을 덜 수 있습니다. 주계약의 경우 월 1,495원으로 50만원까지 보장받으실 수 있으며, 필요에 따라 여러 특약을 선택하실 수 있습니다.\n\n특히 중요한 특약으로 '암 주요 치료보장S특약'이 있습니다. 이 특약을 통해서 고객님은 기타피부암이나 갑상선암을 제외한 암 치료 시 500만원까지 보장받을 수 있습니다. 추가로 '암주요치료비 지원S특약'은 종합병원에서 암 치료 시 연간 치료비가 5백만원 이상일 경우 최대 1억원까지 지원합니다.\n\n또한, 통원치료에 대한 특약도 마련되어 있어, 상급종합병원에서 암 직접 치료를 받을 경우 연간 30회 한도로 최대 50만원을 1회당 보장합니다. 이러한 다양한 특약들을 통해 고객님의 건강을 보다 폭넓게 보호할 수 있습니다.\n\n고객님, 예상치 못한 상황에 대비해 보장을 강화하시는 것을 고려해보시는 것이 어떨까요? 언제라도 추가 질문이 있거나 더 자세한 설명이 필요하시면 편하게 연락 주세요.",
                "sources": [
                {
                    "source_name": "보험설명서",
                    "details": "Page 3-8에서 발췌한 한화생명 시그니처 암치료비보험에 대한 정보"
                }
                ]
            },
            {
                "llm_message": "안녕하세요 고객님. 오늘은 고객님과 고객님의 가족 즉 두 자녀를 고려하여 최적의 암 보험 상품을 소개해드리려고 합니다. 건강을 중시하시는 만큼 암보험의 중요성과 필요성을 느끼고 계실 텐데요.\n\n먼저, 이 상품은 한화생명의 '시그니처 암치료비보장보험'입니다. 고객님과 같은 34세 직장인 남성을 위한 맞춤형 상품입니다. 이 보험은 보험료 부담을 최소화하면서도 암 치료에 필요한 다양한 보장을 제공하는 해약환급금이 없는 형태로 설계되어 있습니다.\n\n기본적으로 50만 원의 가입금액을 가진 주계약을 통해 90세까지 보장받으실 수 있습니다. 월 보험료는 1,495원으로 매우 합리적입니다. 특약을 추가로 선택하여, 고객님의 필요에 맞춘 보장을 강화할 수도 있습니다. 예를 들어, 주요 암 치료보장 특약을 통해 기타피부암과 갑상선암을 제외한 암 진단시 최대 500만 원까지 지원받을 수 있습니다.\n\n종합병원에서의 암 주요 치료비를 연간 1억 원까지 보장받을 수 있는 특약도 준비되어 있습니다. 또한, 상급종합병원에서의 통원치료 보장 특약으로 한 회당 50만 원씩 연간 30회까지 지원되는 항목도 있습니다.\n\n고객님, 암 보험은 예상치 못한 상황에 대비할 수 있는 중요한 자산입니다. 특히 두 자녀가 있는 고객님 가정에게 암 보험의 필요성은 더욱 클 수 있습니다. 지금 바로 가입하셔서 든든한 보장을 받으시는 것은 어떨까요? 질문이나 추가적인 설명이 필요하신 경우 언제든지 연락해 주세요.",
                "sources": [
                {
                    "source_name": "상품설명서",
                    "details": "Page 2"
                },
                {
                    "source_name": "가입금액 및 보험료",
                    "details": "Page 3"
                }
                ]
            },
            {
                "llm_message": "안녕하세요, 고객님. 건강을 중요하게 여기신다는 말씀에 귀를 기울이면서, 암 치료비 보험에 대해 말씀드리고 싶습니다. 한화생명의 시그니처 암치료비보험(무배당)은 고객님의 필요에 꼭 맞는 상품이라고 자신 있게 말씀드릴 수 있습니다.\n\n이 상품은 고객님과 같은 34세 직장인 남성, 그리고 가족을 중요시하는 분들께 특히 유리한 상품입니다. 해약환급금 미지급형을 통해 보험료 부담을 효과적으로 줄이면서도 필수적인 암 치료 보장을 받을 수 있습니다. 주계약으로 50만원의 가입금액에 월 보험료가 매우 합리적입니다. 게다가 다양한 선택 특약을 통해 최대 1억원의 암 치료비까지 보장받을 수 있어 혹시 모를 의료비 부담에서 안심하실 수 있습니다.\n\n고객님께서 주목하실 만한 특약을 소개해드릴게요. 암 주요 치료보장 특약을 통해, 기타피부암과 갑상선암을 제외한 암을 진단받고 치료하실 때 최대 500만원까지 보장받을 수 있습니다. 또한, 암 주요 치료비 지원 S 특약을 통해 종합병원에서의 암 치료비를 연간 최대 1억원까지 보장해드립니다. 상급종합병원에서의 암 직접 치료 동원 S 특약을 가입하시면, 치료 시 1회당 50만원씩 연간 최대 30회 보장도 가능합니다.\n\n고객님, 이러한 보장은 가족과 함께할 소중한 미래를 지키는 데에 중요한 역할을 할 것입니다. 건강을 최우선으로 생각하신다면 이번 기회에 든든한 보장을 마련해 보시는 건 어떨까요? 더 궁금한 점이나 추가로 설명드릴 부분이 있다면 언제든지 문의해 주세요.",
                "sources": [
                {
                    "source_name": "상품설명서",
                    "details": "가입 상품 및 보장내용 요약 (한화생명 시그니처 암치료비보험 제안서, Pages 3-5)"
                },
                {
                    "source_name": "필수 안내사항",
                    "details": "필수 유의사항 (한화생명 시그니처 암치료비보험 제안서, Page 2)"
                }
                ]
            }
        ]

        # 5개의 랜덤 기사를 선택하는 함수
    def get_random_articles(count: int = 1) -> List[Dict]:
        news_= [item["llm_response"] for item in articles]

        return random.sample(news_, count)
        #return random.sample(articles, count)

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "stage_check" : True,
            "llm_response" : get_random_articles(), 
            }
    }

    # return {
    #     "isSuccess" : True,
    #     "code" :"200",
    #     "message": "조회성공",
    #     "data" : {
    #         "response_message":  get_random_articles()
    #     }
    # }

def stage_judge_dummy(fp_id,menu_id,stage,user_query):
    stage_clear = {
        "stage_check" : True ,
        "llm_response": "스테이지에 맞게 잘 대답 하셨어요. ",
    }

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "stage_check" : True ,
            "llm_response": "스테이지에 맞게 잘 대답 하셨어요." 
            }
    }
    
def stage_feedback_dummy(fp_id,menu_id,stage,user_query):
    stage_feedback = {
        "stage_check" : True ,
        "llm_response": "전체적으로 잘 답변하셨어요.다만 상품 설명 부분에서 구체적인 수치가 더 많이 나오면 더 좋을것 같습니다. ",
    }

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "stage_check" : True ,
            "llm_response": "전체적으로 잘 답변하셨어요.다만 상품 설명 부분에서 구체적인 수치가 더 많이 나오면 더 좋을것 같습니다. "
            }
    }



