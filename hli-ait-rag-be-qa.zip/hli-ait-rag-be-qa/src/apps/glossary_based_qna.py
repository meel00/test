import random
from typing import List,Dict
from typing import Optional
from src.utils.aoai_helper import AOAIHelper
from src.utils.db_helper import *
from src.utils.db_query import *
from src.utils.elasticsearch_query import *
from src.utils.util import *
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from src.utils import pdf_table,prompts
from langchain.schema import SystemMessage,HumanMessage
from src.common.logging.logger import LOGGER
import os
import json
import time
import pandas as pd

def glossarybasedqna(request_message):

    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    user_query = request_message.user_query
    #==================================
    aoai = AOAIHelper()
    llm = aoai.openai


    import os
    import sys
    from os import path

    work_dir = path.dirname(path.abspath(__file__))
    sys.path.append(os.path.join(os.path.dirname(__file__),'src/apps'))

    # 1. 엑셀 파일 목록 정의 (파일명만 존재)
    excel_files = {
        '국립암센터_암발생 통계 정보_data': '국립암센터_암발생 통계 정보_20231228.csv',
        '뇌졸중_발생_건수_data': '뇌졸중_발생_건수_20240829083025.csv',
        '뇌출혈 및 뇌경색_data': '뇌출혈 및 뇌경색_1111.xlsx',
        '다빈도 질환별(20개) 수술 (2022)_data': '다빈도 질환별(20개) 수술 (2022)_1111.xlsx',
        '병원종류별 입원_외래 일수_data': '병원종류별 입원_외래 일수_1112.xlsx',
        '심근경색증_발생_건수_data': '심근경색증_발생_건수_20240829083008.csv',
        '심혈관질환_data': '심혈관질환_1111.xlsx',
        '암 상병 진료비 통계_data': '암 상병 진료비 통계 2023_1111.xlsx',
        '암발생 통계 정보_data': '암발생 통계 정보_20231228_1111.csv',
        '입원_외래 현황_data': '입원_외래 현황(_2022)_1112.xlsx',
        '치매발병률_data': 'chimae_1111.xls',
        '항암제_비용_정보(면역, 표적)_data': '항암제_비용_정보(면역, 표적)_1111.csv',
        '협심증_data': '협심증_1111.xlsx'
    }

    # 2. Langchain을 이용하여 질문에 맞는 파일을 선택
    def select_file_based_on_question(user_query):
        # 파일명만 있는 목록을 기반으로 질문에 맞는 파일을 선택
        prompt = f"""
        Given the question '{user_query}', which of the following Excel files would be most relevant to answer the question? 
        The available files are: { excel_files }.
        Please choose the most relevant file.
        """
        
        response = aoai.get_generate_text_response(prompt)
        
        # 응답에서 파일명을 추출
        for file in excel_files.keys():
            if file in response.lower():
                return file
        return None

    # 3. 엑셀 파일 읽기
    def read_excel(file_name):
        file_path = excel_files.get(file_name)
        if file_path:
            try:
                return pd.read_excel(work_dir + "/" + file_path, encoding='EUC-KR')
            except:
                return pd.read_csv(work_dir + "/" + file_path, encoding='EUC-KR')
        else:
            return None

    # 4. RAG 방식으로 질문에 답변하기
    def generate_answer(user_query):
        # 질문에 맞는 파일 선택
        selected_file = select_file_based_on_question(user_query)
        
        if not selected_file:
            return "적합한 데이터 파일을 찾을 수 없습니다."
        
        # 선택된 엑셀 파일 읽기
        data = read_excel(selected_file)
        if data is None:
            return "파일을 읽을 수 없습니다."

        message = f"##질문#: {user_query}   다음 정보를 참고하여 답하세요. ##정보## {data}"  
    
        response = aoai.get_generate_text_response(message)

        return response

        
        # # 데이터 분석 및 질문에 맞는 답변 생성 (예: 특정 데이터 필터링)
        # if 'sales' in question.lower():
        #     return data[['Product', 'Sales']].head()  # 예시: 상위 5개 제품의 판매 데이터 반환
        # elif 'employee' in question.lower():
        #     return data[['Employee Name', 'Department']].head()
        # elif 'inventory' in question.lower():
        #     return data[['Product', 'Stock Level']].head()
        # else:
        #     return "질문에 대한 답변을 찾을 수 없습니다."

    response = generate_answer(user_query)
    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "llm_response" : response, 
            }
    }

def glossarybasedqna_dummy(request_message):

    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    user_query = request_message.user_query
    #==================================
    # 기사 데이터 "제목, 본문, 출처" 형식으로 저장
    articles = [
            {
                "llm_response": "진료비확인은 국민이 요양기관에서 진료를 받고 지불한 비용 중 전액본인부담금과 비급여 진료비가 법령에서 정한 기준에 맞게 부담되었는지를 확인하고, 국민건강보험공단이나 해당 요양기관을 통해 과다본인부담금을 돌려받을 수 있도록 하는 권리구제제도 ",
                "sources": [
                {
                    "source_name": "한화생명 시그니처 암치료비보장보험 상품 안내서",
                    "details": "Page 3"
                }
                ]
            },
            {
                "llm_response": "의료급여제도란	의료급여법에 따라 생활이 어려운 자에게 의료비를 지원하는 제도",
                "sources": [
                {
                    "source_name": "보험설명서",
                    "details": "Page 3-8에서 발췌한 한화생명 시그니처 암치료비보험에 대한 정보"
                }
                ]
            },
            {
                "llm_response": "결정신청이란	요양급여대상여부가 평가되지 아니한 새로운 행위에 대하여 요양급여대상여부 평가 신청",
                "sources": [
                {
                    "source_name": "상품설명서",
                    "details": "Page 2"
                },
                ]
            },
            {
                "llm_response": "폐질이란	치료할 수 없어 불구가 되는 병	",
                "sources": [
                {
                    "source_name": "상품설명서",
                    "details": "가입 상품 및 보장내용 요약 (한화생명 시그니처 암치료비보험 제안서, Pages 3-5)"
                },
                ]
            }
        ]

        # 5개의 랜덤 기사를 선택하는 함수
    def get_random_articles(count: int = 1) -> List[Dict]:
        news_= [item["llm_response"] for item in articles]

        return random.sample(news_, count)
        #return random.sample(articles, count)

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "llm_response" : get_random_articles(), 
            }
    }

