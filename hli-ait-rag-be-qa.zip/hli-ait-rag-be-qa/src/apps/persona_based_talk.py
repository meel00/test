import random
from typing import List,Dict
from typing import Optional
from src.utils.aoai_helper import AOAIHelper
from src.utils.db_helper import *
from src.utils.db_query import *
from src.utils.elasticsearch_query import *
from src.utils.util import *
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from src.utils import pdf_table,prompts
from langchain.schema import SystemMessage,HumanMessage
from src.common.logging.logger import LOGGER
import os
import json
import time


  # 기사 데이터 "제목, 본문, 출처" 형식으로 저장
fewshot = [
            {
                #[화법 1: 시그니처 암치료비보험 - 공감/케어 톤]
                "llm_response": """   
                                    <인삿말>
                    안녕하세요, 고객님. 단풍이 물들어가는 아름다운 계절인데요, 아침저녁으로 느껴지는 선선한 바람에 건강관리가 더욱 중요한 시기인 것 같아요. 일교차도 크고 환절기라 면역력 관리에 더 신경 쓰셔야 할텐데, 요즘 건강관리는 잘 하고 계신가요?

                    <아이스브레이킹>
                    요즘 중년층의 건강에 대해 많이 걱정되는데요. 특히 암 발병률이 증가하고 있어서 더욱 마음이 쓰이죠. 치료 방법은 발전하고 있지만, 그만큼 치료비용도 늘어나고 있어 걱정이 되실 것 같아요.

                    <상품추천 및 강조>
                    그래서 오늘 고객님께 '간편 한화생명 시그니처 암치료비 보험'을 소개해드리고 싶어요.

                    주요 특징을 말씀드리면:
                    1. 최장 10년간 최대 12억까지 암주요 치료비를 보장해드립니다.
                    2. 연간 암 주요치료비 총액 500만원 이상부터 보장이 시작돼요.
                    3. 암이 전이되거나 재발하더라도 신의료기술 치료, 고액치료를 10년간 보장받으실 수 있어요.
                    4. 암 수술, 항암약물치료, 항암방사선치료, 최신 암치료법까지 모두 보장됩니다.

                    이번달 추천드릴 보장은 '암치료비 20억 플랜'인데요:
                    - 표적항암 및 비급여 표적항암 치료비를 5년간 최대 5억원까지 보장해드려요
                    - 암 통원 치료도 회당 100만원씩, 최대 3억원까지 받으실 수 있고
                    - 암 주요치료비 지원과 보장으로 10년간 최대 12억원까지 도와드립니다

                    특히 이 상품은 '간편' 심사 상품이라 과거 병력이 있으신 분들도 가입하실 수 있답니다.

                    <마무리>
                    고객님의 소중한 건강과 미래를 위해 더 자세한 설명을 들어보시면 좋겠어요. 편하신 시간에 맞춰 구체적인 보장내용과 보험료를 상세히 설명해드리고 싶은데, 언제쯤 시간 되실까요?

                """
            },
            {
                #[화법 2: 시그니처 암치료비보험 - 실용적/구체적 톤]
                "llm_response": """ 
                    <인삿말>
                    안녕하세요, 고객님. 일교차가 큰 가을철입니다. 환절기 건강관리도 중요하지만, 장기적인 건강 대비책도 필요한 시기입니다.

                    <아이스브레이킹>
                    암 치료비용을 살펴보면, 수술비용부터 항암치료, 방사선 치료까지 상당한 금액이 필요합니다. 특히 최신 치료법인 표적항암치료는 고액의 치료비가 발생하는데, 이에 대한 실질적인 대비가 필요합니다.

                    <상품추천 및 강조>
                    '간편 한화생명 시그니처 암치료비 보험'의 실질적인 보장 내용을 말씀드리겠습니다.

                    구체적인 보장 내용:
                    1. 암 치료비 보장 기간과 한도
                    - 보장기간: 최장 10년
                    - 보장한도: 최대 12억원
                    - 보장기준: 연간 암 주요치료비 총액 500만원 이상

                    2. 치료 단계별 보장 내용
                    - 암 수술비 보장
                    - 항암약물치료비 보장
                    - 항암방사선치료비 보장
                    - 최신 암치료법 보장

                    이번달 추천드릴 '암치료비 20억 플랜'의 세부 보장내역:
                    - 표적항암치료: 5년간 최대 5억원(일반/비급여 포함)
                    - 암통원치료: 건당 100만원, 누적 3억원
                    - 암주요치료비: 10년간 최대 12억원

                    '간편' 심사로 진행되어:
                    - 과거 병력 있어도 가입 가능
                    - 일반가입형, 100세 만기
                    - 20년납, 해지환급금 미지급형

                    <마무리>
                    구체적인 보험료 산출과 맞춤 설계가 필요하실 텐데요, 자세한 상담을 통해 최적의 보장방안을 찾아보시는 건 어떠실까요?

                """
            },
            {
                #[화법 3: 시그니처 암치료비 보험 - 공감/케어 톤]
                "llm_response": """ 
                   <인삿말>
                    안녕하세요, 고객님. 단풍이 물들어가는 아름다운 계절인데요, 아침저녁으로 느껴지는 선선한 바람에 건강관리가 더욱 중요한 시기인 것 같아요. 일교차도 크고 환절기라 면역력 관리에 더 신경 쓰셔야 할텐데, 요즘 건강관리는 잘 하고 계신가요?

                    <아이스브레이킹>
                    요즘 중년층의 건강에 대해 많이 걱정되는데요. 특히 암 발병률이 증가하고 있어서 더욱 마음이 쓰이죠. 치료 방법은 발전하고 있지만, 그만큼 치료비용도 늘어나고 있어 걱정이 되실 것 같아요.

                    <상품추천 및 강조>
                    그래서 오늘 고객님께 '간편 한화생명 시그니처 암치료비 보험'을 소개해드리고 싶어요.

                    주요 특징을 말씀드리면:
                    1. 최장 10년간 최대 12억까지 암주요 치료비를 보장해드립니다.
                    2. 연간 암 주요치료비 총액 500만원 이상부터 보장이 시작돼요.
                    3. 암이 전이되거나 재발하더라도 신의료기술 치료, 고액치료를 10년간 보장받으실 수 있어요.
                    4. 암 수술, 항암약물치료, 항암방사선치료, 최신 암치료법까지 모두 보장됩니다.

                    이번달 추천드릴 보장은 '암치료비 20억 플랜'인데요:
                    - 표적항암 및 비급여 표적항암 치료비를 5년간 최대 5억원까지 보장해드려요
                    - 암 통원 치료도 회당 100만원씩, 최대 3억원까지 받으실 수 있고
                    - 암 주요치료비 지원과 보장으로 10년간 최대 12억원까지 도와드립니다

                    특히 이 상품은 '간편' 심사 상품이라 과거 병력이 있으신 분들도 가입하실 수 있답니다.

                    <마무리>
                    고객님의 소중한 건강과 미래를 위해 더 자세한 설명을 들어보시면 좋겠어요. 편하신 시간에 맞춰 구체적인 보장내용과 보험료를 상세히 설명해드리고 싶은데, 언제쯤 시간 되실까요?

                """
            },
            {
                # [화법 4: The H 건강보험 - 문제해결 중심 톤]
                "llm_response": """ 
                                            <인삿말>
                        안녕하세요, 고객님. 가을철 일교차가 큰 요즘, 건강관리가 더욱 중요한 시기입니다. 오늘은 건강검진에서 자주 발견되는 대장용종 문제에 대한 실질적인 해결책을 제안드리고자 합니다.

                        <아이스브레이킹>
                        성인의 30%가 가지고 있다는 대장용종, 조기 발견과 치료가 매우 중요한데요. 수술이 필요한 경우 의료비 부담이 큰 걱정거리가 됩니다. 게다가 일반 수술보험은 가입이 어려운 경우도 많죠.

                        <상품추천 및 강조>
                        이러한 문제들을 해결해드리기 위해 'The H 건강보험'을 제안드립니다.

                        문제 해결 방안:
                        1. 수술비 부담 해결
                        - 일반병원: 40만원
                        - 상급종합병원: 100만원
                        - 수술종류별 추가보장: 최대 60만원
                        - 총 최대 200만원까지 보장

                        2. 입원비 부담 해결
                        - 상급종합병원 1인실: 최대 60만원
                        - 종합병원 2~3인실: 최대 20만원

                        3. 보장 범위 확대
                        - 타사합산, 인당한도 제한 없음
                        - 감액, 면책조건 없이 보장
                        - 모든 질병 및 재해 수술 보장

                        이번달 추천드릴 보장은 '대장용종 200만 플랜'입니다. 대장용종 발견 시 수술을 받으시게 되면, 최대 200만원까지 든든하게 보장받으실 수 있습니다.

                        <마무리>
                        고객님의 상황에 맞는 구체적인 보장 설계안을 준비해드리고 싶습니다. 편하신 시간에 실질적인 보장 내용과 해결방안에 대해 자세히 상담해보시는 건 어떠실까요?
가 필요하실 텐데요, 자세한 상담을 통해 최적의 보장방안을 찾아보시는 건 어떠실까요?

                """
            },
             {
                #[화법 5: The H 간병보험 - 스토리텔링 톤]
                "llm_response": """   
                                   <인삿말>
안녕하세요, 고객님. 단풍이 물드는 가을길을 걸으며 생각해보았어요. 우리의 인생도 계절처럼 변화하지만, 그 변화에 미리 준비가 되어있다면 더욱 여유롭게 보낼 수 있겠죠.

<아이스브레이킹>
얼마 전 한 고객님의 이야기가 마음에 와닿았어요. 갑작스러운 부모님의 입원으로 간병에 대한 부담을 직접 경험하셨다고 해요. 입원비도 입원비지만, 간병인 비용이 하루하루 쌓여가는 게 가장 큰 걱정이었다고 하시더라고요.

<상품추천 및 강조>
오늘 소개해드릴 'The H 간병보험'은 그런 걱정을 덜어드리는 든든한 동반자가 될 거예요.

1. 100세까지 함께하는 든든한 보장
   - 비갱신형으로 10년, 20년, 30년 중 선택 가능
   - 합리적인 보험료로 100세까지 보장

2. 다양한 상황에서의 포괄적 보장
   - 상급종합병원, 종합병원 모두 보장
   - 암, 뇌/심 질환 같은 특정질병의 간병도 보장
   - 병실 종류 관계없이 보장 가능

이번달 추천드릴 보장은 '간병인 1억 플랜'입니다. 요양병원 입원만 해도 일당 5만원을 기본으로 지급해드리며, 중증도에 따라 일당 최대 20만원까지 보장됩니다. 1일에서 180일까지는 40만원, 181일에서 365일까지는 15만원이 지급되며, 페이백 900만원을 포함해 최대 1억 875만원의 간병인 비용을 보장받으실 수 있어요.

<마무리>
인생이라는 여정에서 예상치 못한 상황이 찾아올 수 있지만, 이렇게 든든한 준비가 있다면 더 여유롭게 대처하실 수 있을 거예요. 더 자세한 이야기 나누어보시는 건 어떨까요?

                """
            },
            {
                #[화법 6: The H 간병보험 - 실용적/구체적 톤]
                "llm_response": """ 
                    <인삿말>
안녕하세요, 고객님. 환절기를 맞아 면역력 관리가 중요한 시기입니다. 건강관리와 함께 실질적인 간병비 대비도 필요한 때입니다.

<아이스브레이킹>
실제 간병비용을 살펴보면, 하루 간병인 비용이 10만원을 훌쩍 넘어섭니다. 장기 입원이 필요한 경우 매달 수백만원의 간병비가 발생할 수 있어 가계에 큰 부담이 됩니다.

<상품추천 및 강조>
'The H 간병보험'의 구체적인 보장 내용을 설명드리겠습니다:

1. 비갱신형 보장 구조
   - 10년, 20년, 30년납 중 선택
   - 100세까지 보장 지속
   - 합리적인 보험료 유지

2. 병원별 맞춤 보장
   - 상급종합병원 1인실: 최대 60만원/일
   - 종합병원 2~3인실: 최대 20만원/일
   - 1인실/다인실 구분 없이 보장

이번달 추천드릴 '간병인 1억 플랜' 세부 보장내역:
- 요양병원 입원 시 기본 일당 5만원
- 중증도에 따라 일당 최대 20만원까지 보장
- 1~180일: 일당 최대 40만원(체증기준)
- 181~365일: 일당 15만원
- 페이백 900만원 포함 최대 1억 875만원 보장

실제 보장 예시:
- 중증 환자의 3개월 입원 시: 40만원 x 90일
- 경증 환자의 6개월 입원 시: 5만원 x 180일

<마무리>
구체적인 보험료 산출과 맞춤 설계가 필요하실 텐데요, 자세한 상담을 통해 최적의 보장방안을 찾아보시는 건 어떠실까요?

                """
            },
            {
                #[화법 7: 시그니처 암치료비 보험 - 비유/은유적 톤]
                "llm_response": """ 
                   <인삿말>
안녕하세요, 고객님. 마치 울긋불긋 단풍이 가을을 물들이듯, 우리의 건강도 조금씩 변화의 계절을 맞이하고 있어요. 일교차가 큰 계절, 우리 건강에도 든든한 보호막이 필요한 시기입니다.

<아이스브레이킹>
우리의 건강은 마치 정원과도 같아서, 미리미리 가꾸고 준비하지 않으면 예상치 못한 질병이라는 잡초가 자라날 수 있죠. 특히 암이라는 강한 풍파가 불어닥칠 때를 대비한 튼튼한 울타리가 필요합니다.

<상품추천 및 강조>
오늘 소개해드릴 '간편 한화생명 시그니처 암치료비 보험'은 마치 단단한 성벽과도 같은 보험입니다.

든든한 보호막의 세 겹 방어선처럼:
1. 첫 번째 방어선: 최장 10년간 최대 12억까지의 암치료비, 마치 견고한 성벽처럼 지켜드립니다.
2. 두 번째 방어선: 암이 다시 찾아와도, 신의료기술이라는 새로운 무기로 10년간 싸울 수 있어요.
3. 세 번째 방어선: 수술, 항암치료, 방사선 치료까지, 마치 다양한 무기를 갖춘 병사들처럼 준비되어 있습니다.

이번달 추천드릴 '암치료비 20억 플랜'은 마치 삼중 방패와도 같습니다:
- 표적항암이라는 예리한 화살로 5년간 최대 5억원의 방어진을 구축합니다.
- 통원치료라는 날렵한 기병대가 회당 100만원씩, 최대 3억원까지 지원됩니다.
- 암 주요치료비라는 강력한 성채가 10년간 최대 12억원으로 버텨냅니다.

마치 따스한 봄날의 햇살처럼, '간편' 심사로 과거 병력이 있으신 분들도 포근히 품어드립니다.

<마무리>
인생이라는 여정에 든든한 보호막을 마련하는 것, 함께 이야기 나누어보시는 건 어떨까요? 마치 차 한 잔을 나누듯 편안한 마음으로 만나뵙고 싶습니다.

                """
            },
            {
                # [화법 8: The H 건강보험 - 공감/케어 톤]
                "llm_response": """ 
                                           <인삿말>
안녕하세요, 고객님. 가을바람이 선선하게 불어오는 요즘이에요. 일교차가 크니 건강관리가 더욱 중요한데, 평소 건강검진은 잘 받고 계신가요?

<아이스브레이킹>
요즘 들어보면 참 많은 분들이 대장 건강을 걱정하시더라고요. 특히 건강검진에서 대장용종이 발견되었다는 이야기를 자주 들어요. 성인의 30%가 가지고 있다고 하니 누구나 겪을 수 있는 일이죠. 고객님께서도 이런 건강 걱정이 있으실 것 같아요.

<상품추천 및 강조>
그래서 오늘은 'The H 건강보험'을 소개해드리고 싶어요. 

든든한 보장 내용을 말씀드릴게요:
1. 뇌혈관질환, 허혈성심장질환 등 중요한 질환들을 든든하게 보장해드려요.
2. 다른 보험과 상관없이, 제한이나 조건 없이 모든 질병과 재해 수술을 보장받으실 수 있어요.
3. 어느 병원에 입원하시든 걱정 없도록, 상급종합병원이나 종합병원 모두 보장해드립니다.

이번달 추천드릴 보장은 '대장용종 200만 플랜'이에요:
- 일반병원에서 수술받으시면 40만원
- 상급종합병원이라면 100만원
- 거기에 수술 종류에 따라 60만원이 추가되어
- 최대 200만원까지 받으실 수 있답니다

게다가 입원하실 때도 든든하게 보장해드려요:
- 상급종합병원 1인실은 하루 최대 60만원
- 종합병원 2~3인실은 하루 최대 20만원까지

<마무리>
건강 걱정, 혼자 고민하지 마시고 함께 이야기 나눠보아요. 고객님께 꼭 맞는 맞춤 설계를 해드리고 싶은데, 편하실 때 자세한 설명을 들어보시는 건 어떠실까요?

                """
            },
            {
                #[화법 9: The H 간병보험 - 통계/데이터 중심 톤]
                "llm_response": """ 
                   <인삿말>
안녕하세요, 고객님. 가을철 일교차가 큰 환절기에는 면역력 관리가 특히 중요한 시기입니다. 건강관리와 함께 미래 의료비 대비도 필요한 때입니다.

<아이스브레이킹>
현재 간병인 일일 비용은 평균 10-15만원 수준이며, 매년 상승 추세를 보이고 있습니다. 장기 입원 시 간병비가 의료비보다 더 큰 부담이 될 수 있다는 점이 주목됩니다.

<상품추천 및 강조>
'The H 간병보험'의 구체적인 보장 데이터를 분석해드리겠습니다:

1. 보험 기간 및 납입 구조 분석
   - 보장기간: 100세까지
   - 납입기간: 10년, 20년, 30년 선택형
   - 형태: 비갱신형으로 보험료 고정

2. 병원 유형별 보장 금액
   - 상급종합병원 1인실: 일일 최대 60만원
   - 종합병원 2~3인실: 일일 최대 20만원
   - 병실 종류 무관 보장

이번달 추천드릴 '간병인 1억 플랜' 세부 보장내역:
- 기본 보장: 요양병원 입원 시 일당 5만원
- 중증도별 보장:
  * 중도 환자: 일당 10만원
  * 최고도 환자: 일당 20만원
- 기간별 보장:
  * 1-180일: 일당 40만원(체증기준)
  * 181-365일: 일당 15만원
- 총 보장한도: 페이백 900만원 포함 최대 1억 875만원

<마무리>
구체적인 보장 설계와 보험료 산출이 필요하실 것 같습니다. 상세 데이터를 바탕으로 한 맞춤 상담을 진행해드리고 싶은데, 편하신 시간에 만나뵐 수 있을까요?

                """
            },
            {
                # [화법 10: The H 건강보험 - 문제해결 중심 톤]
                "llm_response": """ 
                        <인삿말>
안녕하세요, 고객님. 환절기 면역력 관리도 중요하지만, 장기적인 건강 대비책도 필요한 시기입니다. 특히 수술이나 입원과 같은 큰 의료비 부담에 대한 해결책을 말씀드리고자 합니다.

<아이스브레이킹>
대장용종의 경우, 성인의 30%가 가지고 있으며 조기 발견과 치료가 매우 중요합니다. 하지만 수술비와 입원비 부담으로 치료 시기를 놓치는 경우가 많죠. 이런 경제적 부담을 효과적으로 해결할 방법이 필요합니다.

<상품추천 및 강조>
이러한 문제들을 해결해드리기 위해 'The H 건강보험'을 제안드립니다.

주요 해결방안:
1. 수술비 부담 해결
   - 일반병원 질병재해수술: 40만원
   - 상급종합병원 질병재해수술: 100만원
   - 수술종류별 추가보장: 60만원
   - 통합 최대 보장: 200만원

2. 입원비 부담 해결
   - 상급종합병원 1인실: 일당 최대 60만원
   - 종합병원 2~3인실: 일당 최대 20만원
   - 병실 종류 제한 없음

3. 보험가입 제한 문제 해결
   - 타사 가입여부 무관
   - 한도 제한 없음
   - 감액, 면책조건 없이 즉시 보장

이번달 추천드릴 '대장용종 200만 플랜'은 이러한 문제들을 종합적으로 해결해드립니다. 대장용종 발견 시 수술과 입원에 대한 걱정 없이 빠른 치료가 가능하도록 도와드립니다.

<마무리>
고객님의 상황에 맞는 구체적인 보장 설계가 필요하실 텐데요, 직접 만나뵙고 최적의 해결방안을 찾아보시는 건 어떠실까요? 편하신 시간에 맞춰 자세한 상담 진행해드리겠습니다.


                """
            }
        ]

def mysqltest(request_message):
    mysqlHelper = MySQLHelper()
    mysqlHelper.connect()
    oResult = mysqlHelper.select_query("select * from tbl_aitcnvvc09")
    return oResult

def personabasedtalk(request_message):
    start_time = time.time()
    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    age = request_message.age
    gender = request_message.gender
    career_field = request_message.career_field
    product_name = request_message.product_name
    product_tag = request_message.product_tag
    news_id = request_message.news_id
    #==================================

    aoai = AOAIHelper()
    llm = aoai.openai

    def make_ice_breaking(weather_news=None, good_news=None):

        data = aoai.get_prompt_by_id("001")

        system_Message =SystemMessage(content=json.dumps(data["system_template"]['content'],ensure_ascii=False))
        LOGGER.debug(system_Message)

        userPrompt = data["human_template"]
        context_text = f"날씨뉴스: {weather_news}, 시사뉴스: {good_news}"
        userPrompt['content']['context'] = context_text

        human_Message =HumanMessage(content=json.dumps(userPrompt['content'],ensure_ascii=False))
        LOGGER.debug(human_Message)
        message = [system_Message,human_Message]
        
        response = aoai.get_generate_text_response(message)

        LOGGER.debug(response)

        return response


    # 퓨샷 2개 랜덤 선택하는 함수
    def get_random_articles(count: int = 2) -> List[Dict]:
        news_ = get_fewshot("FR02","GPT02")
        LOGGER.debug("news_","FR02","GPT02",news_)
        if len(news_)==0:
            news_= [item["llm_response"] for item in fewshot]
        random_value = random.randint(0,2)
        return random.sample(news_, random_value)


    # JSON 문자열을 파싱하여 Python 딕셔너리로 변환
    data = aoai.get_prompt_by_id("003")

    system_Message =SystemMessage(content=json.dumps(data["system_template"]['content'],ensure_ascii=False))
    LOGGER.debug(system_Message)

    userPrompt = data["human_template"]

    user = get_age_group(age) + " " + get_gender(gender) 
    fewshots = get_random_articles()
    domain_ = get_prduct_info(product_name)

    domain = f"""
    **내용** : {domain_}
    """
    
    # 아이스브레이킹용 기사 먼저 발췌
    # 날씨와 기사 모두 랜덤하게 가져온다 
    weather = get_weather_news()
    news,news_url = get_news_by_id(news_id)

    #아이스브레이킹
    #icebreaking = make_ice_breaking(weather_news,news)

    # 템플릿에서 변수 치환
    context_text =   f"""
                        user: {user},
                        날씨뉴스: {weather},
                        시사뉴스: {news},
                        domain: {domain},
                        fewshot:  {fewshots}
                     """

    userPrompt['content']['context'] = context_text

    human_Message =HumanMessage(content=json.dumps(userPrompt['content'],ensure_ascii=False))
    LOGGER.debug(human_Message)

    message = [system_Message,human_Message]

    # LLM을 호출하여 응답 생성
    response = aoai.get_generate_text_response(message)
    LOGGER.debug(response)
    llm_responae = response
    end_time = time.time()
    elapsed_time = end_time -start_time
    start_time =time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(start_time))
    end_time =time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(end_time))
    oresult = "start : " + str(start_time) + "===>" + "end :" + str(end_time) + "===>" + "elapsed :" + str(elapsed_time)
    LOGGER.debug(oresult)

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "llm_response" : llm_responae, 
            "news_url": news_url
            }
    }


def personabasedtalk_(request_message):

    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    age = request_message.age
    gender = request_message.gender
    career_field = request_message.career_field
    product_name = request_message.product_name
    product_tag = request_message.product_tag
    news_id = request_message.news_id
    #==================================

    aoai = AOAIHelper()
    llm = aoai.openai

    def make_ice_breaking(weather_news=None, good_news=None):
        # weather_info = prompts.weather  # 날씨 정보
        # news_info = prompts.news  # 뉴스 기사 정보

        # JSON 문자열을 파싱하여 Python 딕셔너리로 변환
        data = aoai.get_prompt_by_id("001")

        # json_string = json.dumps(data["template"])[1:-1].encode('utf-8').decode('unicode_escape')
        # prompt_template = PromptTemplate.from_template(json_string)

        # prompt_template = prompt_template.format(weather = weather_news , news = good_news  )
        # chain =LLMChain(llm=llm, prompt=prompt_template)
        # response = chain.invoke().content

        # return response

        # 템플릿에서 변수 치환
        context_text = f"기사1: {weather_news}, 기사2: {good_news}"
        data['context'] = context_text

        formatted_prompt = json_to_string(data)
        print("formatted_prompt",formatted_prompt)

        # chain =LLMChain(llm=llm, prompt=formatted_prompt)
        # response = chain.invoke().content

        # LLM을 호출하여 응답 생성
        response = aoai.get_generate_text_response(formatted_prompt)
        
        # # LLM을 호출하여 응답 생성
        # response = llm.chat.completions.create(
        #     temperature=0.5, 
        #     model=deployment_name,
        #     messages=[
        #         {"role": "system", "content": "You are a helpful assistant."},
        #         {"role": "user", "content": formatted_prompt}
        #     ]
        # )
        #print(response)
        #return response.choices[0].message.content
        return response.content


    
    # 퓨샷 2개 랜덤 선택하는 함수
    def get_random_articles(count: int = 2) -> List[Dict]:
        news_= [item["llm_response"] for item in fewshot]
        random_value = random.randint(0,2)
        return random.sample(news_, random_value)
        #return random.sample(articles, count)

    
  # JSON 문자열을 파싱하여 Python 딕셔너리로 변환
    data = aoai.get_prompt_by_id("004")

    
    #chain =LLMChain(llm=llm, prompt=prompt_template)
    
    #query = "건강보험 20대 남성"
    user = get_age_group(age) + " " + get_gender(gender) 
    fewshots = get_random_articles()
    domain_ =get_prduct_info(product_name)

    domain = f"""
    **내용** : {domain_}
    """
    
    #아이스브레이킹용 기사 먼저 발췌
    weather_news = get_weather_news()
    news = get_news_by_id(news_id)

    #아이스브레이킹
    icebreaking = make_ice_breaking(weather_news,news)

    #prompt_template = PromptTemplate(input_variables=[user = user , icebreaking = icebreaking ,domain = domain,fewshot  = fewshots],json_to_string(data["template"]))

    # prompt_template = prompt_template.format(user = user , icebreaking = icebreaking ,domain = domain,fewshot  = fewshots)
    # chain =LLMChain(llm=llm, prompt=prompt_template)
    # llm_responae = chain.invoke().content


    #llm_responae = chain.run(user = user , icebreaking = icebreaking ,domain = domain,fewshot  = fewshots)


    # 템플릿에서 변수 치환
    context_text = f"""
                     user: {user},
                     icebreaking: {icebreaking},
                     domain: {domain},
                     fewshot:  {fewshots}"""

    data['template']['context'] = context_text

    formatted_prompt = json_to_string(data['template'])
    print("formatted_prompt",formatted_prompt)


    # LLM을 호출하여 응답 생성
    response = aoai.get_generate_text_response(formatted_prompt)
    llm_responae = response

    # #1.상품정보 가져오기 with "product_name"
    # #2.기사아이디로 기사 가져오기 엘라스틱서치 

    print(llm_responae)

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "llm_response" : llm_responae, 
            "news_url": "news_url"
            }
    }





def personabasedtalk_dummy(request_message):

    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    age = request_message.age
    gender = request_message.gender
    career_field = request_message.career_field
    product_name = request_message.product_name
    product_tag = request_message.product_tag
    news_id = request_message.news_id
    #==================================

    # 기사 데이터 "제목, 본문, 출처" 형식으로 저장
    articles = [
            {
                "llm_response": "고객님, 현재 건강에 대한 관심이 높아지고 있는 만큼 암 보험은 꼭 필요하다고 할 수 있습니다. 고객님의 프로필을 확인해보니, 34세 남성 직장인이시고 자녀가 두 명 있는 가장으로서 건강에 더욱 신경 쓰고 계시군요. 이를 고려하여 한화생명의 시그니처 암치료비보장보험을 추천드립니다.\n\n이 보험은 장기적으로 암 치료에 필요한 자금을 보장받으며, 보험료 부담을 줄일 수 있는 해약환급금 미지급형 상품입니다. 특히 90세까지 보장받으실 수 있어 노후까지 대비가 가능합니다. 주계약으로 가입하실 경우 월 1,495원의 보험료로 기본 보장을 받을 수 있습니다.\n\n암 주요 치료보장S 특약을 통해서 고객님께서 가장 우려하시는 종합병원 및 상급종합병원 암 치료비를 지원받을 수 있고, 최대 1억원까지 치료를 보장받으실 수 있습니다. 이 외에도 여러 특약들이 있어 고객님의 필요에 맞게 구성할 수 있습니다. 예를 들어, 연간 암주요치료비가 500만원 이상일 경우 1억원까지 보장되며, 상급종합병원 통원치료 시에는 50만원씩 보장합니다.\n\n고객님께서 관심이 가실만한 점은, 주계약뿐만 아니라 다양한 특약을 추가할 수 있다는 점입니다. 암 주요 치료비 지원 특약이나 통원치료비 특약을 통해 더욱 폭넓은 보장을 받으실 수 있습니다. 중요한 것은 언제 또 어떤 일이 발생할지 모르는 상황에 대비하는 것입니다.\n\n지금 바로 가입하셔서 든든한 보장을 받으시는 것도 좋을 듯합니다. 궁금한 점이나 추가로 궁금하신 사항이 있으시면 언제든지 연락 주시기 바랍니다.",
                "sources": [
                {
                    "source_name": "한화생명 시그니처 암치료비보장보험 상품 안내서",
                    "details": "해약환급금 미지급형 상품으로 90세까지의 장기 보장을 제공합니다. 보험료는 가입자의 나이, 조건 등에 따라 달라질 수 있으며, 보장금액 및 특약 선택에 따라 변경됩니다."
                }
                ]
            },
            {
                "llm_response": "안녕하세요 고객님, 건강을 중요시하시는 고객님을 위해 암 보험 상품을 소개해드리려고 합니다. 이 상품은 한화생명의 시그니처 암치료비보장보험(무배당)으로, 고객님의 필요에 맞춰 다양한 보장을 제공하고 있습니다.\n\n이 보험은 90세 만기, 5년 납입 조건으로 설정되어 있으며, 해약환급금 미지급형을 통해 보험료 부담을 덜 수 있습니다. 주계약의 경우 월 1,495원으로 50만원까지 보장받으실 수 있으며, 필요에 따라 여러 특약을 선택하실 수 있습니다.\n\n특히 중요한 특약으로 '암 주요 치료보장S특약'이 있습니다. 이 특약을 통해서 고객님은 기타피부암이나 갑상선암을 제외한 암 치료 시 500만원까지 보장받을 수 있습니다. 추가로 '암주요치료비 지원S특약'은 종합병원에서 암 치료 시 연간 치료비가 5백만원 이상일 경우 최대 1억원까지 지원합니다.\n\n또한, 통원치료에 대한 특약도 마련되어 있어, 상급종합병원에서 암 직접 치료를 받을 경우 연간 30회 한도로 최대 50만원을 1회당 보장합니다. 이러한 다양한 특약들을 통해 고객님의 건강을 보다 폭넓게 보호할 수 있습니다.\n\n고객님, 예상치 못한 상황에 대비해 보장을 강화하시는 것을 고려해보시는 것이 어떨까요? 언제라도 추가 질문이 있거나 더 자세한 설명이 필요하시면 편하게 연락 주세요.",
                "sources": [
                {
                    "source_name": "보험설명서",
                    "details": "Page 3-8에서 발췌한 한화생명 시그니처 암치료비보험에 대한 정보"
                }
                ]
            },
            {
                "llm_response": "안녕하세요 고객님. 오늘은 고객님과 고객님의 가족 즉 두 자녀를 고려하여 최적의 암 보험 상품을 소개해드리려고 합니다. 건강을 중시하시는 만큼 암보험의 중요성과 필요성을 느끼고 계실 텐데요.\n\n먼저, 이 상품은 한화생명의 '시그니처 암치료비보장보험'입니다. 고객님과 같은 34세 직장인 남성을 위한 맞춤형 상품입니다. 이 보험은 보험료 부담을 최소화하면서도 암 치료에 필요한 다양한 보장을 제공하는 해약환급금이 없는 형태로 설계되어 있습니다.\n\n기본적으로 50만 원의 가입금액을 가진 주계약을 통해 90세까지 보장받으실 수 있습니다. 월 보험료는 1,495원으로 매우 합리적입니다. 특약을 추가로 선택하여, 고객님의 필요에 맞춘 보장을 강화할 수도 있습니다. 예를 들어, 주요 암 치료보장 특약을 통해 기타피부암과 갑상선암을 제외한 암 진단시 최대 500만 원까지 지원받을 수 있습니다.\n\n종합병원에서의 암 주요 치료비를 연간 1억 원까지 보장받을 수 있는 특약도 준비되어 있습니다. 또한, 상급종합병원에서의 통원치료 보장 특약으로 한 회당 50만 원씩 연간 30회까지 지원되는 항목도 있습니다.\n\n고객님, 암 보험은 예상치 못한 상황에 대비할 수 있는 중요한 자산입니다. 특히 두 자녀가 있는 고객님 가정에게 암 보험의 필요성은 더욱 클 수 있습니다. 지금 바로 가입하셔서 든든한 보장을 받으시는 것은 어떨까요? 질문이나 추가적인 설명이 필요하신 경우 언제든지 연락해 주세요.",
                "sources": [
                {
                    "source_name": "상품설명서",
                    "details": "Page 2"
                },
                {
                    "source_name": "가입금액 및 보험료",
                    "details": "Page 3"
                }
                ]
            },
            {
                "llm_response": "안녕하세요, 고객님. 건강을 중요하게 여기신다는 말씀에 귀를 기울이면서, 암 치료비 보험에 대해 말씀드리고 싶습니다. 한화생명의 시그니처 암치료비보험(무배당)은 고객님의 필요에 꼭 맞는 상품이라고 자신 있게 말씀드릴 수 있습니다.\n\n이 상품은 고객님과 같은 34세 직장인 남성, 그리고 가족을 중요시하는 분들께 특히 유리한 상품입니다. 해약환급금 미지급형을 통해 보험료 부담을 효과적으로 줄이면서도 필수적인 암 치료 보장을 받을 수 있습니다. 주계약으로 50만원의 가입금액에 월 보험료가 매우 합리적입니다. 게다가 다양한 선택 특약을 통해 최대 1억원의 암 치료비까지 보장받을 수 있어 혹시 모를 의료비 부담에서 안심하실 수 있습니다.\n\n고객님께서 주목하실 만한 특약을 소개해드릴게요. 암 주요 치료보장 특약을 통해, 기타피부암과 갑상선암을 제외한 암을 진단받고 치료하실 때 최대 500만원까지 보장받을 수 있습니다. 또한, 암 주요 치료비 지원 S 특약을 통해 종합병원에서의 암 치료비를 연간 최대 1억원까지 보장해드립니다. 상급종합병원에서의 암 직접 치료 동원 S 특약을 가입하시면, 치료 시 1회당 50만원씩 연간 최대 30회 보장도 가능합니다.\n\n고객님, 이러한 보장은 가족과 함께할 소중한 미래를 지키는 데에 중요한 역할을 할 것입니다. 건강을 최우선으로 생각하신다면 이번 기회에 든든한 보장을 마련해 보시는 건 어떨까요? 더 궁금한 점이나 추가로 설명드릴 부분이 있다면 언제든지 문의해 주세요.",
                "sources": [
                {
                    "source_name": "상품설명서",
                    "details": "가입 상품 및 보장내용 요약 (한화생명 시그니처 암치료비보험 제안서, Pages 3-5)"
                },
                {
                    "source_name": "필수 안내사항",
                    "details": "필수 유의사항 (한화생명 시그니처 암치료비보험 제안서, Page 2)"
                }
                ]
            }
        ]

        # 5개의 랜덤 기사를 선택하는 함수
    def get_random_articles(count: int = 1) -> List[Dict]:
        news_= [item["llm_response"] for item in articles]

        return random.sample(news_, count)
        #return random.sample(articles, count)

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "llm_response" : get_random_articles(), 
            "news_url": "news_url"
            }
    }
    # return {
    #     "isSuccess" : True,
    #     "code" :"200",
    #     "message": "조회성공",
    #     "data" : {
    #         "response_message":  get_random_articles()
    #     }
    # }
