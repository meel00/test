import random
from typing import List,Dict
from typing import Optional

def virtualclientbasedtalk(fp_id,menu_id,stage):

   
    # 기사 데이터 "제목, 본문, 출처" 형식으로 저장
    articles = [
            {
                "llm_message": "고객님, 현재 건강에 대한 관심이 높아지고 있는 만큼 암 보험은 꼭 필요하다고 할 수 있습니다. 고객님의 프로필을 확인해보니, 34세 남성 직장인이시고 자녀가 두 명 있는 가장으로서 건강에 더욱 신경 쓰고 계시군요. 이를 고려하여 한화생명의 시그니처 암치료비보장보험을 추천드립니다.\n\n이 보험은 장기적으로 암 치료에 필요한 자금을 보장받으며, 보험료 부담을 줄일 수 있는 해약환급금 미지급형 상품입니다. 특히 90세까지 보장받으실 수 있어 노후까지 대비가 가능합니다. 주계약으로 가입하실 경우 월 1,495원의 보험료로 기본 보장을 받을 수 있습니다.\n\n암 주요 치료보장S 특약을 통해서 고객님께서 가장 우려하시는 종합병원 및 상급종합병원 암 치료비를 지원받을 수 있고, 최대 1억원까지 치료를 보장받으실 수 있습니다. 이 외에도 여러 특약들이 있어 고객님의 필요에 맞게 구성할 수 있습니다. 예를 들어, 연간 암주요치료비가 500만원 이상일 경우 1억원까지 보장되며, 상급종합병원 통원치료 시에는 50만원씩 보장합니다.\n\n고객님께서 관심이 가실만한 점은, 주계약뿐만 아니라 다양한 특약을 추가할 수 있다는 점입니다. 암 주요 치료비 지원 특약이나 통원치료비 특약을 통해 더욱 폭넓은 보장을 받으실 수 있습니다. 중요한 것은 언제 또 어떤 일이 발생할지 모르는 상황에 대비하는 것입니다.\n\n지금 바로 가입하셔서 든든한 보장을 받으시는 것도 좋을 듯합니다. 궁금한 점이나 추가로 궁금하신 사항이 있으시면 언제든지 연락 주시기 바랍니다.",
                "sources": [
                {
                    "source_name": "한화생명 시그니처 암치료비보장보험 상품 안내서",
                    "details": "해약환급금 미지급형 상품으로 90세까지의 장기 보장을 제공합니다. 보험료는 가입자의 나이, 조건 등에 따라 달라질 수 있으며, 보장금액 및 특약 선택에 따라 변경됩니다."
                }
                ]
            },
            {
                "llm_message": "안녕하세요 고객님, 건강을 중요시하시는 고객님을 위해 암 보험 상품을 소개해드리려고 합니다. 이 상품은 한화생명의 시그니처 암치료비보장보험(무배당)으로, 고객님의 필요에 맞춰 다양한 보장을 제공하고 있습니다.\n\n이 보험은 90세 만기, 5년 납입 조건으로 설정되어 있으며, 해약환급금 미지급형을 통해 보험료 부담을 덜 수 있습니다. 주계약의 경우 월 1,495원으로 50만원까지 보장받으실 수 있으며, 필요에 따라 여러 특약을 선택하실 수 있습니다.\n\n특히 중요한 특약으로 '암 주요 치료보장S특약'이 있습니다. 이 특약을 통해서 고객님은 기타피부암이나 갑상선암을 제외한 암 치료 시 500만원까지 보장받을 수 있습니다. 추가로 '암주요치료비 지원S특약'은 종합병원에서 암 치료 시 연간 치료비가 5백만원 이상일 경우 최대 1억원까지 지원합니다.\n\n또한, 통원치료에 대한 특약도 마련되어 있어, 상급종합병원에서 암 직접 치료를 받을 경우 연간 30회 한도로 최대 50만원을 1회당 보장합니다. 이러한 다양한 특약들을 통해 고객님의 건강을 보다 폭넓게 보호할 수 있습니다.\n\n고객님, 예상치 못한 상황에 대비해 보장을 강화하시는 것을 고려해보시는 것이 어떨까요? 언제라도 추가 질문이 있거나 더 자세한 설명이 필요하시면 편하게 연락 주세요.",
                "sources": [
                {
                    "source_name": "보험설명서",
                    "details": "Page 3-8에서 발췌한 한화생명 시그니처 암치료비보험에 대한 정보"
                }
                ]
            },
            {
                "llm_message": "안녕하세요 고객님. 오늘은 고객님과 고객님의 가족 즉 두 자녀를 고려하여 최적의 암 보험 상품을 소개해드리려고 합니다. 건강을 중시하시는 만큼 암보험의 중요성과 필요성을 느끼고 계실 텐데요.\n\n먼저, 이 상품은 한화생명의 '시그니처 암치료비보장보험'입니다. 고객님과 같은 34세 직장인 남성을 위한 맞춤형 상품입니다. 이 보험은 보험료 부담을 최소화하면서도 암 치료에 필요한 다양한 보장을 제공하는 해약환급금이 없는 형태로 설계되어 있습니다.\n\n기본적으로 50만 원의 가입금액을 가진 주계약을 통해 90세까지 보장받으실 수 있습니다. 월 보험료는 1,495원으로 매우 합리적입니다. 특약을 추가로 선택하여, 고객님의 필요에 맞춘 보장을 강화할 수도 있습니다. 예를 들어, 주요 암 치료보장 특약을 통해 기타피부암과 갑상선암을 제외한 암 진단시 최대 500만 원까지 지원받을 수 있습니다.\n\n종합병원에서의 암 주요 치료비를 연간 1억 원까지 보장받을 수 있는 특약도 준비되어 있습니다. 또한, 상급종합병원에서의 통원치료 보장 특약으로 한 회당 50만 원씩 연간 30회까지 지원되는 항목도 있습니다.\n\n고객님, 암 보험은 예상치 못한 상황에 대비할 수 있는 중요한 자산입니다. 특히 두 자녀가 있는 고객님 가정에게 암 보험의 필요성은 더욱 클 수 있습니다. 지금 바로 가입하셔서 든든한 보장을 받으시는 것은 어떨까요? 질문이나 추가적인 설명이 필요하신 경우 언제든지 연락해 주세요.",
                "sources": [
                {
                    "source_name": "상품설명서",
                    "details": "Page 2"
                },
                {
                    "source_name": "가입금액 및 보험료",
                    "details": "Page 3"
                }
                ]
            },
            {
                "llm_message": "안녕하세요, 고객님. 건강을 중요하게 여기신다는 말씀에 귀를 기울이면서, 암 치료비 보험에 대해 말씀드리고 싶습니다. 한화생명의 시그니처 암치료비보험(무배당)은 고객님의 필요에 꼭 맞는 상품이라고 자신 있게 말씀드릴 수 있습니다.\n\n이 상품은 고객님과 같은 34세 직장인 남성, 그리고 가족을 중요시하는 분들께 특히 유리한 상품입니다. 해약환급금 미지급형을 통해 보험료 부담을 효과적으로 줄이면서도 필수적인 암 치료 보장을 받을 수 있습니다. 주계약으로 50만원의 가입금액에 월 보험료가 매우 합리적입니다. 게다가 다양한 선택 특약을 통해 최대 1억원의 암 치료비까지 보장받을 수 있어 혹시 모를 의료비 부담에서 안심하실 수 있습니다.\n\n고객님께서 주목하실 만한 특약을 소개해드릴게요. 암 주요 치료보장 특약을 통해, 기타피부암과 갑상선암을 제외한 암을 진단받고 치료하실 때 최대 500만원까지 보장받을 수 있습니다. 또한, 암 주요 치료비 지원 S 특약을 통해 종합병원에서의 암 치료비를 연간 최대 1억원까지 보장해드립니다. 상급종합병원에서의 암 직접 치료 동원 S 특약을 가입하시면, 치료 시 1회당 50만원씩 연간 최대 30회 보장도 가능합니다.\n\n고객님, 이러한 보장은 가족과 함께할 소중한 미래를 지키는 데에 중요한 역할을 할 것입니다. 건강을 최우선으로 생각하신다면 이번 기회에 든든한 보장을 마련해 보시는 건 어떨까요? 더 궁금한 점이나 추가로 설명드릴 부분이 있다면 언제든지 문의해 주세요.",
                "sources": [
                {
                    "source_name": "상품설명서",
                    "details": "가입 상품 및 보장내용 요약 (한화생명 시그니처 암치료비보험 제안서, Pages 3-5)"
                },
                {
                    "source_name": "필수 안내사항",
                    "details": "필수 유의사항 (한화생명 시그니처 암치료비보험 제안서, Page 2)"
                }
                ]
            }
        ]

        # 5개의 랜덤 기사를 선택하는 함수
    def get_random_articles(count: int = 1) -> List[Dict]:
        news_= [item["llm_response"] for item in articles]

        return random.sample(news_, count)
        #return random.sample(articles, count)

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "stage_check" : True,
            "llm_response" : get_random_articles(), 
            }
    }

    # return {
    #     "isSuccess" : True,
    #     "code" :"200",
    #     "message": "조회성공",
    #     "data" : {
    #         "response_message":  get_random_articles()
    #     }
    # }

def stage_judge(fp_id,menu_id,stage,user_query):
    stage_clear = {
        "stage_check" : True ,
        "llm_response": "스테이지에 맞게 잘 대답 하셨어요. ",
    }

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "stage_check" : True ,
            "llm_response": "스테이지에 맞게 잘 대답 하셨어요." 
            }
    }
    

def stage_feedback(fp_id,menu_id,stage,user_query):
    stage_feedback = {
        "stage_check" : True ,
        "llm_response": "전체적으로 잘 답변하셨어요.다만 상품 설명 부분에서 구체적인 수치가 더 많이 나오면 더 좋을것 같습니다. ",
    }

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "stage_check" : True ,
            "llm_response": "전체적으로 잘 답변하셨어요.다만 상품 설명 부분에서 구체적인 수치가 더 많이 나오면 더 좋을것 같습니다. "
            }
    }

def virtualclientbasedtalk_stage(request_message) -> List[Dict]:
     # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    name = request_message.name
    age = request_message.age
    gender = request_message.gender
    address = request_message.address
    news_id = request_message.news_id
    coverage_analysis = request_message.coverage_analysis
    stage = request_message.stage
    user_query = request_message.user_query
    #==================================

    if stage == "0":
        return virtualclientbasedtalk(fp_id,menu_id,stage)
    else:
        #마지막 턴인 경우 99
        if stage=="99":
            return stage_feedback(fp_id,menu_id,stage,user_query)
        else:
            return stage_judge(fp_id,menu_id,stage,user_query)