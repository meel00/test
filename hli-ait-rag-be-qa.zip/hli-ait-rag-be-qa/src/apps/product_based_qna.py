import random
from typing import List,Dict
from typing import Optional
from src.utils.aoai_helper import AOAIHelper
from src.utils.db_helper import *
from src.utils.db_query import *
from src.utils.elasticsearch_query import *
from src.utils.util import *
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from langchain.chains import RetrievalQA
#from langchain.chains.question_answering import load_qa_chain
#from langchain.vectorstores import ElasticsearchVectorSearch
from src.common.logging.logger import LOGGER
from langchain.schema import SystemMessage,HumanMessage
import json
from src.utils.aoai_helper import AOAIHelper

def productbasedqna_dummy(request_message):

    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    proposal_number = request_message.proposal_number
    user_query = request_message.user_query
    #==================================
    # 기사 데이터 "제목, 본문, 출처" 형식으로 저장
    articles = [
            {
                "llm_response": "진료비확인은 국민이 요양기관에서 진료를 받고 지불한 비용 중 전액본인부담금과 비급여 진료비가 법령에서 정한 기준에 맞게 부담되었는지를 확인하고, 국민건강보험공단이나 해당 요양기관을 통해 과다본인부담금을 돌려받을 수 있도록 하는 권리구제제도 ",
                "sources": [
                {
                    "source_name": "한화생명 시그니처 암치료비보장보험 상품 안내서",
                    "details": "Page 3"
                }
                ]
            },
            {
                "llm_response": "의료급여제도란	의료급여법에 따라 생활이 어려운 자에게 의료비를 지원하는 제도",
                "sources": [
                {
                    "source_name": "보험설명서",
                    "details": "Page 3-8에서 발췌한 한화생명 시그니처 암치료비보험에 대한 정보"
                }
                ]
            },
            {
                "llm_response": "결정신청이란	요양급여대상여부가 평가되지 아니한 새로운 행위에 대하여 요양급여대상여부 평가 신청",
                "sources": [
                {
                    "source_name": "상품설명서",
                    "details": "Page 2"
                },
                ]
            },
            {
                "llm_response": "폐질이란	치료할 수 없어 불구가 되는 병	",
                "sources": [
                {
                    "source_name": "상품설명서",
                    "details": "가입 상품 및 보장내용 요약 (한화생명 시그니처 암치료비보험 제안서, Pages 3-5)"
                },
                ]
            }
        ]

        # 5개의 랜덤 기사를 선택하는 함수
    def get_random_articles(count: int = 1) -> List[Dict]:
        news_= [item["llm_response"] for item in articles]

        return random.sample(news_, count)
        #return random.sample(articles, count)

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "llm_response" : get_random_articles(), 
            }
    }


def productbasedqna(request_message):
    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    proposal_number = request_message.proposal_number
    user_query = request_message.user_query
    #==================================

    retriever = get_productproposal_based_qna_source_pdf(request_message)
    LOGGER.debug(retriever)

    aoai = AOAIHelper()
    
    message = f"##질문#: {user_query}   다음 정보를 참고하여 답하세요. ##정보## {retriever}"  
    
    response = aoai.get_generate_text_response(message)

    # #Q&A 체인 설정**
    # qa_chain = RetrievalQA.from_chain_type(
    #     llm=llm,
    #     retriever=retriever,
    #     return_source_documents=True
    # )

    # result = qa_chain({"query": user_query})
    

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "llm_response" : response, 
            }
    }


def productbasedqna_test(request_message):
    from langchain.schema import SystemMessage,HumanMessage
    import json
    from src.utils.aoai_helper import AOAIHelper
   
    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    proposal_number = request_message.proposal_number
    user_query = request_message.user_query
    #==================================

    retriever = get_qna_source(request_message)
    LOGGER.debug(retriever)

    aoai = AOAIHelper()
    
    message = f"##질문#: {user_query}   다음 정보를 참고하여 답하세요. ##정보## {retriever}"  
    
    response = aoai.get_generate_text_response(message)

    # #Q&A 체인 설정**
    # qa_chain = RetrievalQA.from_chain_type(
    #     llm=llm,
    #     retriever=retriever,
    #     return_source_documents=True
    # )

    # result = qa_chain({"query": user_query})


    # 프롬프트 템플릿 정의 (필요에 따라 조정 가능)
    prompt_template = PromptTemplate(
        input_variables=["context", "question"],
        template="""
        다음 문서를 참고하여 질문에 답변해 주세요:
        
        문서:
        {context}
        
        질문:
        {question}
        """
    )

    # LLM 및 QA 체인 로드
    llm = aoai.openai
    # 적절한 chain_type 설정
    chain_type = "stuff"  # 예를 들어 "stuff", "map_reduce" 등
    qa_chain = load_qa_chain(llm,chain_type=chain_type, prompt=prompt_template)

    #csv_file_path = "./retrievers/glossary.csv"  # PDF 파일 경로
    documents = get_qna_source(request_message)

    # 모든 문서를 대상으로 질문을 수행
    result = qa_chain.run(input_documents=documents, question=user_query)
    response_message = result
    
    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "llm_response" : response_message, 
            }
    }



    