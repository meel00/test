import random
from typing import List,Dict
from typing import Optional
from src.utils.elastic_helper import SearchQuery
import src.utils.elasticsearch_query as esQuery
from src.common.logging.logger import LOGGER

def icebreakingnews(request_message):
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    results = esQuery.get_ice_breaking_news(request_message)
    # BM25 검색 후 KNN 리랭크
    news_= [item["_source"] for item in results]

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "news": news_
            }
    }

def icebreakingnews_dummy(request_message):
    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    age = request_message.age
    gender = request_message.gender
    career_field = request_message.career_field
    product_name = request_message.product_name
    product_tag = request_message.product_tag

    print("request_message",request_message)
    
    # 날씨 데이터
    weather_info = {
            "news_id" : "sds123",
            "news_title": "오늘의 날씨",
            "news_date":"2024-11-03",
            "news_url": "https://www.yna.co.kr/view/AKR20241018008700004?input=1195m"
            }

    # 기사 데이터 "제목, 본문, 출처" 형식으로 저장
    articles = [
        {
        "news_id" : "sds124",
        "news_title": "10억 로또, 동탄이 끝이었나 못 먹어도 고 줍줍, 사라진다?[부릿지]",
        "news_date": "2024-11-03",
        "news_url": "https://news.mt.co.kr/mtview.php?no=2024101714282253227&MTS_P"
        },
        {
        "news_id" : "sds125",
        "news_title": "한국 방산 또 일냈다…'천궁-Ⅱ' 이라크에 3.5조원 계약 임박",
        "news_date": "2024-11-03",
        "news_url": "https://the300.mt.co.kr/newsView.html?no=2024091123400491677&pDepth1=policy_sub13&pDepth2="
        },
        {
        "news_id" : "sds126",
        "news_title": "美 대선 불확실성·신와르 피살에…금값, 또 사상 최고치 경신",
        "news_date": "2024-11-03",
        "news_url": "https://www.edaily.co.kr/News/Read?newsId=01787606639054232&mediaCodeNo=257"
        },
        {
        "news_id" : "sds127",
        "news_title": "우주 탐사 시대의 도래",
        "news_date": "2024-11-03",
        "news_url": "https://www.edaily.co.kr/News/Read?newsId=03844166639053904&mediaCodeNo=257"
        },
        {
        "news_id" : "sds128",
        "news_title": "신약 개발과 의료 혁신",
        "news_date": "2024-11-03",
        "news_url": "https://www.edaily.co.kr/articles/society/medical"
        },
        {
        "news_id" : "sds224",
        "news_title": "210억 로또, 동탄이 끝이었나 못 먹어도 고 줍줍, 사라진다?[부릿지]",
        "news_date": "2024-11-03",
        "news_url": "https://news.mt.co.kr/mtview.php?no=2024101714282253227&MTS_P"
        },
        {
        "news_id" : "sds225",
        "news_title": "#한국 방산 또 일냈다…'천궁-Ⅱ' 이라크에 3.5조원 계약 임박",
        "news_date": "2024-11-03",
        "news_url": "https://the300.mt.co.kr/newsView.html?no=2024091123400491677&pDepth1=policy_sub13&pDepth2="
        },
        {
        "news_id" : "sds226",
        "news_title": "#美 대선 불확실성·신와르 피살에…금값, 또 사상 최고치 경신",
        "news_date": "2024-11-03",
        "news_url": "https://www.edaily.co.kr/News/Read?newsId=01787606639054232&mediaCodeNo=257"
        },
        {
        "news_id" : "sds227",
        "news_title": "#우주 탐사 시대의 도래",
        "news_date": "2024-11-03",
        "news_url": "https://www.edaily.co.kr/News/Read?newsId=03844166639053904&mediaCodeNo=257"
        },
        {
        "news_id" : "sds228",
        "news_title": "#신약 개발과 의료 혁신",
        "news_date": "2024-11-03",
        "news_url": "https://www.edaily.co.kr/articles/society/medical"
        }
    ]

        # 5개의 랜덤 기사를 선택하는 함수
    def get_random_articles(count: int = 5) -> List[Dict]:
        return random.sample(articles, count)


    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "news": get_random_articles()
            }
    }

def icebreakingnews_rrf(request_message):

    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    results = esQuery.get_ice_breaking_news_rrf_unique(request_message)
    # rrf 쿼리 진행
    news_= [item["_source"] for item in results]

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "news": news_
            }
    }

def icebreaking_test(request_message):
    from langchain.schema import SystemMessage,HumanMessage
    import json
    from src.utils.aoai_helper import AOAIHelper
    from src.utils.elasticsearch_query import get_weather_news,get_news_by_id
    aoai = AOAIHelper()

    news_id = request_message.news_id
    weather_news = get_weather_news()
    good_news = get_news_by_id(news_id)

    # JSON 문자열을 파싱하여 Python 딕셔너리로 변환
    data = aoai.get_prompt_by_id("005")

    system_Message =SystemMessage(content=json.dumps(data["system_template"]['content'],ensure_ascii=False))
    LOGGER.debug(system_Message)

    userPrompt = data["human_template"]
    context_text = f"날씨뉴스: {weather_news}, 시사뉴스: {good_news}"
    userPrompt['content']['context'] = context_text

    human_Message =HumanMessage(content=json.dumps(userPrompt['content'],ensure_ascii=False))
    LOGGER.debug(human_Message)
    message = [system_Message,human_Message]
    
    response = aoai.get_generate_text_response(message)

    LOGGER.debug(response)

    return response


def icebreaking_test_local(request_message):
    from langchain.schema import SystemMessage,HumanMessage
    import json
    #from src.utils.aoai_helper import AOAIHelper
    #from src.utils.elasticsearch_query import get_weather_news,get_news_by_id
    #aoai = AOAIHelper()

    # news_id = request_message.news_id
    # weather_news = get_weather_news()
    # good_news = get_news_by_id(news_id)

    weather_news = "get_weather_news()"
    good_news = "get_news_by_id(news_id)"

    # JSON 문자열
    prompt_63 = {
    "prompts": [
        {
        "id": "005",
        "prompt_type": "Ice_breaking prompt",
        "system_template": {
            "content" : {
                "goal": " 주어진 컨텍스트와 지침에 따라 고객과의 대화에서 자연스러운 아이스브레이킹을 한다.",
                "instructions": [
                "경어를 사용하여 대화문구를 작성할 것.",
                "대화의 흐름이 자연스럽고 유연하게 이어지도록 작성할 것."
                ],
                "constraints": [
                "인사말, 후킹 메시지는 포함하지 말 것.",
                "단순히 기사정보를 제공하는 데 그치지 않고, 기사 내용을 적절히 연결할 것."
                ],
                "length": "최대 200단어",
                "tone & manner": "전문적이고 설득력 있는 어조"
            }
        },
        "human_template": {
            "content" : {
                "goal": "{{context}}를 활용해 고객과의 대화에서 자연스러운 아이스브레이킹을 한다.",
                "context": {
                    "기사1": "{{weather}}",
                    "기사2": "{{news}}"
                }
            }
        }
        },
        {
        "id": "001",
        "prompt_type": "Ice_breaking prompt",
        "template": {
            "roles": "보험 전문가",
            "goal": "{{context}}를 활용해 고객과의 대화에서 자연스러운 아이스브레이킹을 한다.",
            "context": {
            "기사1": "{{weather}}",
            "기사2": "{{news}}"
            },
            "instructions": [
            "경어를 사용하여 대화문구를 작성할 것.",
            "대화의 흐름이 자연스럽고 유연하게 이어지도록 작성할 것."
            ],
            "constraints": [
            "인사말, 후킹 메시지는 포함하지 말 것.",
            "단순히 기사정보를 제공하는 데 그치지 않고, 기사 내용을 적절히 연결할 것."
            ],
            "format": "대화문구",
            "length": "최대 500자",
            "tone & manner": "전문적이고 설득력 있는 어조"
        }
        },
        {
        "id": "002",
        "prompt_type": "Narrative_client_based_talk prompt",
        "template": {
            "role": "보험 전문가",
            "goal": "{{context}}를 활용해,각 단계로 화법을 생성한다. 1.인사말 2.아이스브레이킹 3.상품홍보 4.끝인사",
            "context": {
                "user" : "{{user}}",
                "icebreaking": "{{icebreaking}}",
                "domain": "{{domain}}",
                "fewshot": "{{fewshot}}"
            },
            "instructions": [
                "경어를 사용하여 대화문구를 작성할 것.",
                "대화의 흐름이 자연스럽고 유연하게 이어지도록 작성할 것."
            ],
            "constraints": [
                "단순히 순서대로 대화생성에 그치지 않고, 대화 단계를 매끄럽게 연결할 것.",
                "fewshot 은 화법생성에 참고만 하고 내용은 차용하지 말것"
            ],
            "format": {
                "message": "<Generated response to the query>",
                    "sources": [
                        {
                            "source_name": "<Name of the source; pdf page,url,etc>",
                            "details": "<Details or relevant information from the source ; page no>"
                        }
                    ]
            },
            "length": "최대 2000자",
            "tone & manner": "전문적이고 설득력 있는 어조"
        }
        },
        {
        "id": "004",
        "prompt_type": "Narrative_persona_based_talk prompt",
        "template": {
            "roles": "보험 전문가",
            "goal": "{{context}}를 활용해,각 단계로 화법을 생성한다. 1.인사말 2.아이스브레이킹 3.상품홍보 4.끝인사",
            "context": {
                "user" : "{{user}}",
                "icebreaking": "{{icebreaking}}",
                "domain": "{{domain}}",
                "fewshot": "{{fewshot}}"
            },
            "instructions": [
                "경어를 사용하여 대화문구를 작성할 것.",
                "대화의 흐름이 자연스럽고 유연하게 이어지도록 작성할 것."
            ],
            "constraints": [
                "단순히 순서대로 대화생성에 그치지 않고, 대화 단계를 매끄럽게 연결할 것.",
                "fewshot 은 화법생성에 참고만 하고 내용은 차용하지 말것",
                "fewshot 의 화법을 최대한 흉내낼것"
            ],
            "출력포맷": [
                "답변을 먼저 출력하고 출처를 명기해주는데 출처는 분리할 수 있게 구분자를 넣어줘. 클라이언트에는 안보여줄거야",
            ],
            "length": "최대 2000자",
            "tone & manner": "전문적이고 설득력 있는 어조"
        }
        },
        {
            "id": "003",
            "prompt_type": "Narrative_productproposal_based prompt",
            "template": {
                "role": "보험 전문가",
                "goal": "{{context}}를 활용해서 fewshot의 화법과 유사한 패턴으로 화법을 생성해",
                "context": {
                    "user": "{{user}}",
                    "domain": "{{domain}}",
                    "fewshot": "{{fewshot}}"
                },
                "instructions": [
                    "출력 **format** 형식을 반드시 지킬것",
                    "경어를 사용하여 대화 문구를 작성할 것.",
                    "대화의 흐름이 자연스럽고 유연하게 이어지도록 작성할 것.",
                    "**user** 정보를 꼭 언급할것"
                ],
                "constraints": [
                    "단순히 순서대로 대화 생성에 그치지 않고, 대화 단계를 매끄럽게 연결할 것.",
                    "fewshot은 화법 생성에 참고만 하고, 내용은 차용하지 말 것.",
                    "아이스브레이킹 부분은 생략할 것."
                ],
                "format": {
                    "message": "<Generated response to the query>",
                    "sources": [
                        {
                            "source_name": "<Name of the source; pdf page,url,etc>",
                            "details": "<Details or relevant information from the source ; page no>"
                        }
                    ]
                },
                "length": "최대 2000자",
                "tone & manner": "전문적이고 설득력 있는 어조"
            }
        }

    ]
    }

        # JSON을 파싱하고 특정 id의 prompt를 찾는 함수
    def get_prompt_by_id(target_id):
        #parsed_data = json.loads(prompts.prompt_63)  # Assuming prompts.prompt_63 is a valid JSON string
        parsed_data = prompt_63  # Assuming prompts.prompt_63 is a valid JSON string
        for prompt in parsed_data["prompts"]:
            if prompt["id"] == target_id:
                return prompt
        return None  # 해당 id가 없을 경우 None 반환


    # JSON 문자열을 파싱하여 Python 딕셔너리로 변환
    data = get_prompt_by_id("005")

    system_Message =SystemMessage(content=json.dumps(data["system_template"]['content']))

    userPrompt = data["human_template"]
    context_text = f"기사1: {weather_news}, 기사2: {good_news}"
    userPrompt['context'] = context_text

    human_Message =HumanMessage(content=json.dumps(userPrompt['content']))

    message = [system_Message,human_Message]
    
    response = aoai.get_generate_text_response(formatted_prompt)

    return response.content

#icebreaking_test(None)






###################################  개발중 #################
def icebreakingnews_BM25(request_message):

    # # 입력 파라미터
    # fp_id = request_message.fp_id
    # menu_id = request_message.menu_id
    # #==================================
    # age = request_message.age
    # gender = request_message.gender
    # career_field = request_message.career_field
    # product_name = request_message.product_name
    # product_tag = request_message.product_tag
    # #==================================

    search_instance = SearchQuery(index="tbl_lparag0200")
    # BM25 검색 후 KNN 리랭크
    results = search_instance.search_BM25(request_message)

    news_= [item["_source"] for item in results]

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "news": news_
            }
    }

def icebreakingnews_KNN(request_message):

    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    age = request_message.age
    gender = request_message.gender
    career_field = request_message.career_field
    product_name = request_message.product_name
    product_tag = request_message.product_tag
    #==================================

    search_instance = SearchQuery(index="tbl_lparag0200")
    # BM25 검색 후 KNN 리랭크
    results = search_instance.search_KNN(product_name)

    news_= [item["_source"] for item in results]

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "news": news_
            }
    }

def icebreakingnews_BM25_KNN(request_message):

    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    age = request_message.age
    gender = request_message.gender
    career_field = request_message.career_field
    product_name = request_message.product_name
    product_tag = request_message.product_tag
    #==================================

    search_instance = SearchQuery(index="tbl_lparag0200")
    # BM25 검색 후 KNN 리랭크
    results = search_instance.search_BM25_KNN(product_name)

    news_= [item["_source"] for item in results]

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "news": news_
            }
    }

def icebreakingnews_BM25_KNNONELOGIC(request_message):

    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    age = request_message.age
    gender = request_message.gender
    career_field = request_message.career_field
    product_name = request_message.product_name
    product_tag = request_message.product_tag
    #==================================

    search_instance = SearchQuery(index="tbl_lparag0200")
    # BM25 검색 후 KNN 리랭크
    results = search_instance.search_BM25_KNNONELOGIC(product_name)

    news_= [item["_source"] for item in results]

    return {
        "is_success" : True,
        "code" :"200",
        "message": "조회성공",
        "response_message" : {
            "fp_id": fp_id ,
            "menu_id" : menu_id, 
            "news": news_
            }
    }

