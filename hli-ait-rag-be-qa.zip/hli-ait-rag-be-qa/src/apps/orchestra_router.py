# routers/sample_router.py

from fastapi import APIRouter
from pydantic import BaseModel, Field
from typing import List,Dict
from typing import Optional,Union
import random

from src.apps.client_based_talk import *
from src.apps.glossary_based_qna import *
from src.apps.rate_based_qna import *
from src.apps.icebreaking_news import *
from src.apps.persona_based_talk import *
from src.apps.picking_good_talk import pickinggoodtalk
from src.apps.product_based_qna import *
from src.apps.productproposal_based_talk import *
from src.apps.simulation_virtual_talk import *
from src.apps.virtual_client_based_talk import *
from src.apps.virtual_persona_based_talk import *
from src.apps.aoai_test import *
# from src.utils.elastic_helper import SearchQuery
from src.utils.elastic_dummy import insert_data
from src.utils.elastic_helper import SearchQuery


class RequestMessage(BaseModel):
    fp_id: Optional[str]= Field(None)
    # 이건 필요없다고 한다 ##
    menu_id: Optional[str]= Field(None)
    # 이건 필요없다고 한다 ##
    name: Optional[str]= Field(None)
    age: Optional[str]= Field(None)
    gender: Optional[str]= Field(None)
    career_field : Optional[str]= Field(None)
    product_name : Optional[str]= Field(None)
    product_tag : Optional[str]= Field(None)
    address: Optional[str]= Field(None)
    news_id: Optional[str]= Field(None)
    proposal_number : Optional[str]= Field(None)
    coverage_analysis: Optional[dict]= Field(None)
    stage: Optional[str]= Field(None)
    user_query: Optional[str]= Field(None)

    class Config:
        arbitrary_types_allowed = True  # 필요한 경우 활성화

# class RequestMessage(BaseModel):
#     fp_id: Optional[Union[str,int,float]]= None
#     # 이건 필요없다고 한다 ##
#     menu_id: Optional[Union[str,int,float]]= None
#     # 이건 필요없다고 한다 ##
#     name: Optional[Union[str,int,float]]= None
#     age: Optional[Union[str,int,float]]= None
#     gender: Optional[Union[str,int,float]]= None
#     career_field : Optional[Union[str,int,float]]= None
#     product_name : Optional[Union[str,int,float]]= None
#     product_tag : Optional[Union[str,int,float]]= None
#     address: Optional[Union[str,int,float]]= None
#     news_id: Optional[Union[str,int,float]]= None
#     proposal_number : Optional[Union[str,int,float]]= None
#     coverage_analysis: Optional[dict]= None
#     stage: Optional[Union[str,int,float]]= None
#     user_query: Optional[Union[str,int,float]]= None

class ChatRequest(BaseModel):
    request_message: RequestMessage

# AOAI ,BGE-m3 테스트용
class RequestMessage1(BaseModel):
    user_query: Optional[Union[str,int,float]]= None

class ChatRequest1(BaseModel):
    request_message1: RequestMessage1

# APIRouter 인스턴스 생성
router = APIRouter()

@router.post("/api/orc/get_ice_breaking_news")
async def get_ice_breaking_news(chat_request: ChatRequest):
    # 찐 Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message

    print("request_message:", request_message)
    """
    10.아이스브레이킹용 기사조회 엔드포인트입니다.
    """
    #return icebreakingnews(request_message)
    return icebreakingnews_rrf(request_message)
    #return "10.아이스브레이킹용 기사조회"


# @router.post("/get_ice_breaking_news_rrf")
# async def get_ice_breaking_news_rrf(chat_request: ChatRequest):
#     # Pydantic을 사용해 자동으로 JSON 파싱
#     request_message = chat_request.request_message

#     print("request_message:", request_message)
#     """
#     10.아이스브레이킹용 기사조회 엔드포인트입니다.
#     """
#     return get_ice_breaking_news_rrf_unique(request_message)
#     #return "10.아이스브레이킹용 기사조회"


@router.post("/get_mysql_query_test")
async def get_db_test(chat_request: ChatRequest):
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message

    print("request_message:", request_message)
    """
    10.아이스브레이킹용 기사조회 엔드포인트입니다.
    """
    return get_query(request_message)
    #return "10.아이스브레이킹용 기사조회"


@router.post("/api/orc/make_client_based_talk")
async def make_client_based_talk_dummy(chat_request: ChatRequest):
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message
    print("request_message:", request_message)
    """
    1.나의 고객 상품추천 화법 생성하는 엔드포인트입니다.
    """

    return clientbasedtalk_dummy(request_message)
    return "1.나의 고객 상품추천 화법 생성"


@router.post("/make_client_based_talk")
async def make_client_based_talk(chat_request: ChatRequest):
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message
    print("request_message:", request_message)
    """
    1.나의 고객 상품추천 화법 생성하는 엔드포인트입니다.
    """

    return clientbasedtalk(request_message)
    return "1.나의 고객 상품추천 화법 생성"


@router.post("/api/orc/make_persona_based_talk")
async def make_persona_based_talk_dummy(chat_request: ChatRequest):
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message
    print("request_message:", request_message)
    """
    2.가상 고객 상품추천 화법 생성하는 엔드포인트입니다.

    프로덕트네임으로 RDB가서 상품특징을 가져와서 도메인 프롬프크 구성한다.
    기사ID는 넘어오니까 다시 엘라스틱서치에서 본문을 찾아온다.
    """
    return personabasedtalk_dummy(request_message)
    return "2.가상 고객 상품추천 화법 생성"


@router.post("/make_persona_based_talk")
async def make_persona_based_talk(chat_request: ChatRequest):
    # 찐 Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message
    print("request_message:", request_message)
    """
    2.가상 고객 상품추천 화법 생성하는 엔드포인트입니다.

    프로덕트네임으로 RDB가서 상품특징을 가져와서 도메인 프롬프크 구성한다.
    기사ID는 넘어오니까 다시 엘라스틱서치에서 본문을 찾아온다.
    """
    return personabasedtalk(request_message)
    return "2.가상 고객 상품추천 화법 생성"


@router.post("/api/orc/make_proposal_based_talk")
async def make_proposal_based_talk_dummy(chat_request: ChatRequest):
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message
    print("request_message:", request_message)
    """
    3.가입설계서 기반 화법 생성하는 엔드포인트입니다.
    """
    return productproposalbasedtalk_dummy(request_message)
    return "3.가입설계서 기반 화법 생성"


@router.post("/make_proposal_based_talk")
async def make_proposal_based_talk(chat_request: ChatRequest):
    # 찐 Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message
    print("request_message:", request_message)
    """
    3.가입설계서 기반 화법 생성하는 엔드포인트입니다.
    """
    return productproposalbasedtalk(request_message)
    return "3.가입설계서 기반 화법 생성"


@router.post("/api/orc/picking_good_talk")
async def picking_good_talk(chat_request: ChatRequest):
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message
    print("request_message:", request_message)
    """
    4.우수 화법 선별 엔드포인트입니다.
    """

    return pickinggoodtalk()
    # # data = await request.json()
    # # request_message = data['request_message']

    # # 평가 기준을 설명하는 프롬프트 템플릿 정의
    # prompt_template = PromptTemplate(
    #     input_variables=["description"],
    #     template="""
    #     다음 상품 설명을 평가해 주세요.각 평가는 20자 이내로 명료하게 해주세요.

    #     설명: {description}

    #     평가 기준:
    #     1. 정확성: 설명이 상품의 특징을 정확하게 설명하고 있습니까? (0-10점)
    #     2. 설득력: 소비자가 상품을 구매하고 싶게 만듭니까? (0-10점)
    #     3. 문맥 적합성: 설명이 상품과 문맥적으로 맞습니까? (0-10점)
    #     4. 명료성: 설명이 명확하고 이해하기 쉽습니까? (0-10점)

    #     총점을 0에서 40점 사이로 평가해 주세요.
    #     """
    # )

    # # LangChain LLM 초기화
    # llm = OpenAI(temperature=1)
    # evaluation_chain = prompt_template | llm

    # # Pydantic 모델 정의 (입력 및 출력 데이터 구조)
    # class DescriptionRequest(BaseModel):
    #     descriptions: List[str]

    # class DescriptionResponse(BaseModel):
    #     best_description: str
    #     score: int
    
    # try:
    #     scores = []
    #     total_score = 0
    #     # 각 설명에 대해 LLM을 사용하여 점수 평가
    #     score_str = evaluation_chain.invoke({"description": request_message})
    #     # 점수만 추출
    #     try:
    #         scores = [int(score) for score in re.findall(r'(\d+)점', score_str)]
    #         #total_score = int(re.search(r'총점: (\d+)', score_str).group(1))
    #         total_score = scores[-1]
    #     except:
    #         pass

    #     print("개별 점수:", scores)
    #     print("총점:", total_score)

    #     best_scores = []
    #     best_scores.append((request_message, total_score))
        
    #     # 점수가 가장 높은 설명 선택
    #     best_description, best_score = max(best_scores, key=lambda x: x[1])
    #     #return DescriptionResponse(best_description=best_description, score=best_score)
    #     #response_message = best_description + "점수 : " + str(best_score) + "점  ====> " + score_str
    #     response_message = score_str
    #     return JSONResponse(content={"response_message": response_message})


    # except Exception as e:
    #     raise HTTPException(status_code=500, detail=str(e))
    # #return "4.우수 화법 선별"


@router.post("/api/orc/make_product_based_qna")
async def make_product_based_qna_dummy(chat_request: ChatRequest):
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message # Pydantic 모델을 dict로 변환
    print("request_message:", request_message)
    """
    5.상품 질의 응답 엔드포인트입니다.
    """
    return productbasedqna_dummy(request_message)


@router.post("/make_product_based_qna")
async def make_product_based_qna(chat_request: ChatRequest):
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message # Pydantic 모델을 dict로 변환
    print("request_message:", request_message)
    """
    5.상품 질의 응답 엔드포인트입니다.
    """
    return productbasedqna(request_message)

##### 제일 어려운 부분이라고 합니다 시작#####

@router.post("/api/orc/convert_client_based_talk")
async def convert_client_based_talk(chat_request: ChatRequest):
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message
    print("request_message:", request_message)
    """
    6.가상 대화 전환-고객특정 엔드포인트입니다.
    """
    return virtualclientbasedtalk_stage(request_message)
    return "6.가상 대화 전환-고객특정"


@router.post("/api/orc/convert_persona_based_talk")
async def convert_persona_based_talk(chat_request: ChatRequest):
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message
    print("request_message:", request_message)
    """
    7.가상 대화 전환-페르소나 엔드포인트입니다.
    """
    return virtualpersonabasedtalk_stage(request_message)
    return "7.가상 대화 전환-페르소나"



@router.post("/api/orc/make_simulation_virtual_talk")
async def make_simulation_virtual_talk_dummy(chat_request: ChatRequest):
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message
    print("request_message:", request_message)
    """
    8.시뮬레이션 가상 대화 엔드포인트입니다.
    """
    return simulationvirtualtalk_stage_dummy(request_message)
    return "8.시뮬레이션 가상 대화"


@router.post("/make_simulation_virtual_talk")
async def make_simulation_virtual_talk(chat_request: ChatRequest):
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message
    print("request_message:", request_message)
    """
    8.시뮬레이션 가상 대화 엔드포인트입니다.
    """
    return simulationvirtualtalk_stage(request_message)
    return "8.시뮬레이션 가상 대화"

##### 제일 어려운 부분이라고 합니다 끝#####

@router.post("/api/orc/make_glossary_based_qna")
async def make_glossary_based_qna_dummy(chat_request: ChatRequest):
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message
    print("request_message:", request_message)
    """
    9.용어 검색 대화 엔드포인트입니다.
    """

    return glossarybasedqna_dummy(request_message)

@router.post("/api/orc/make_rate_based_qna")
async def make_rate_based_qna_dummy(chat_request: ChatRequest):
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message
    print("request_message:", request_message)
    """
    9.용어 검색 대화 엔드포인트입니다.
    """

    return ratebasedqna_dummy(request_message)


@router.post("/make_glossary_based_qna")
async def make_glossary_based_qna(chat_request: ChatRequest):
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message
    print("request_message:", request_message)
    """
    9.용어 검색 대화 엔드포인트입니다.
    """

    return glossarybasedqna(request_message)

@router.post("/make_rate_based_qna")
async def make_rate_based_qna(chat_request: ChatRequest):
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request.request_message
    print("request_message:", request_message)
    """
    9.용어 검색 대화 엔드포인트입니다.
    """

    return ratebasedqna(request_message)


# @router.post("/make_icebreaking_test")
# async def make_icebreaking_test(chat_request: ChatRequest):
#     # Pydantic을 사용해 자동으로 JSON 파싱
#     request_message = chat_request.request_message
#     print("request_message:", request_message)
#     """
#     9.용어 검색 대화 엔드포인트입니다.
#     """

#     return icebreaking_test(request_message)

    # # data = await request.json()
    # # request_message = data['request_message']

    # # 프롬프트 템플릿 정의 (필요에 따라 조정 가능)
    # prompt_template = PromptTemplate(
    #     input_variables=["context", "question"],
    #     template="""
    #     다음 문서를 참고하여 질문에 답변해 주세요:
        
    #     문서:
    #     {context}
        
    #     질문:
    #     {question}
    #     """
    # )

    # # LLM 및 QA 체인 로드
    # llm = OpenAI(temperature=0)
    # # 적절한 chain_type 설정
    # chain_type = "stuff"  # 예를 들어 "stuff", "map_reduce" 등
    # qa_chain = load_qa_chain(llm,chain_type=chain_type, prompt=prompt_template)

    # csv_file_path = "./retrievers/glossary.csv"  # PDF 파일 경로
    # documents = data_manager.csv_retriever(csv_file_path)

    # # 모든 문서를 대상으로 질문을 수행
    # result = qa_chain.run(input_documents=documents, question=request_message)
    # response_message = result
    # return JSONResponse(content={"response_message": response_message})



@router.post("/aoai_test")
async def aoai_test(chat_request1: ChatRequest1):
    """
    AOAI 테스트 엔드포인트입니다.
    질문을 하거나, 완성된 프롬프트를 넣으세요.
    """
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request1.request_message1
    # print("request_message:", request_message)
    
    return aoaitest(request_message.user_query)
    #return icebreakingnews()
    #return "10.아이스브레이킹용 기사조회"


@router.post("/aoai_test_tpm")
async def aoai_test_tpm(chat_request1: ChatRequest1):
    import random
    import json
    import requests
    from datetime import datetime
    from src.common.logging.logger import LOGGER

    

    """
    AOAI 테스트 엔드포인트입니다.
    질문을 하거나, 완성된 프롬프트를 넣으세요.
    """
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request1.request_message1
    # print("request_message:", request_message)
    LOGGER.debug("es검색시작 : ")
    LOGGER.debug(datetime.today())
    # TPM발생을 위한 테스트 es에서 뉴스검색 > 1개 랜덤으로 선택 > 뉴스타이틀 임베딩, 프롬프트후 gpt호출
    search_instance = SearchQuery(index="tbl_lparag0200")
    es_result = search_instance.search_tpm()
    LOGGER.debug("es검색종료 : ")
    LOGGER.debug(datetime.today())
        
    cnt = len(es_result)
        
    target = random.randrange(0, cnt)
    sample = es_result[target]["_source"]
    titletext = sample["news_title"]
    
 
    prompt = "아래 내용에 대해 요약해줘"
    for i in range(1, 21):
        target = random.randrange(0, cnt)
        sample = es_result[target]["_source"]
        prompt = prompt + "\n" + sample["news_content"]
        if i < 11 :
            titletext = titletext + sample["news_title"]

    title = [titletext] 
    
    LOGGER.debug("임베딩 시작 : ")
    LOGGER.debug(datetime.today())
    
    BGE_API_URL = "http://hli-ait-emb-be-svc-active.hli-ait-ns-emb.svc.cluster.local/embedding/dense_vector"  # BGE-m3 API URL
    response = requests.post(BGE_API_URL,headers={"accept": "application/json", "Content-Type":"application/json"},data = json.dumps(title))
    LOGGER.debug("임베딩 종료 : ")
    LOGGER.debug(datetime.today())
    

    LOGGER.debug("llm 시작 : ")
    LOGGER.debug(datetime.today())
    result = aoaitest(prompt)
    LOGGER.debug("llm 종료 : ")
    LOGGER.debug(datetime.today())
    
    
    LOGGER.debug("LLM 결과============== :")
    LOGGER.debug(result)
    

    return result
    #return icebreakingnews()
    #return "10.아이스브레이킹용 기사조회"


@router.post("/aoai_test_10k")
async def aoai_test_10k(chat_request1: ChatRequest1):
    """
    AOAI 테스트 엔드포인트입니다.
    질문을 하거나, 완성된 프롬프트를 넣으세요.
    """
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request1.request_message1
    # print("request_message:", request_message)

    a,b = aoaitest_10k(request_message.user_query)
    
    return a,b
    #return icebreakingnews()
    #return "10.아이스브레이킹용 기사조회"

@router.post("/aoai_test_20k")
async def aoai_test_20k(chat_request1: ChatRequest1):
    """
    AOAI 테스트 엔드포인트입니다.
    질문을 하거나, 완성된 프롬프트를 넣으세요.
    """
    # Pydantic을 사용해 자동으로 JSON 파싱
    request_message = chat_request1.request_message1
    # print("request_message:", request_message)
    a,b = aoaitest_20k(request_message.user_query)

    return a,b


# @router.post("/aoai_test1")
# async def aoai_test1(chat_request: ChatRequest):

#     # Pydantic을 사용해 자동으로 JSON 파싱
#     request_message = chat_request.request_message
#     # print("request_message:", request_message)
#     """
#     10.아이스브레이킹용 기사조회 엔드포인트입니다.
#     """
#     return aoaitest1(request_message.user_query)
#     #return icebreakingnews()
#     #return "10.아이스브레이킹용 기사조회"

# @router.post("/aoai_test2")
# async def aoai_test2(chat_request: ChatRequest):

#     # Pydantic을 사용해 자동으로 JSON 파싱
#     request_message = chat_request.request_message
#     # print("request_message:", request_message)
#     """
#     10.아이스브레이킹용 기사조회 엔드포인트입니다.
#     """
#     return aoaitest2(request_message.user_query)
#     #return icebreakingnews()
#     #return "10.아이스브레이킹용 기사조회"

# @router.post("/aoai_test3")
# async def aoai_test3(chat_request: ChatRequest):

#     # Pydantic을 사용해 자동으로 JSON 파싱
#     request_message = chat_request.request_message
#     # print("request_message:", request_message)
#     """
#     10.아이스브레이킹용 기사조회 엔드포인트입니다.
#     """
#     return aoaitest3(request_message.user_query)
#     #return icebreakingnews()
#     #return "10.아이스브레이킹용 기사조회"

# @router.post("/es_test")
# async def es_test(chat_request: ChatRequest):

#     # Pydantic을 사용해 자동으로 JSON 파싱
#     request_message = chat_request.request_message
#     # print("request_message:", request_message)
#     """
#     10.아이스브레이킹용 기사조회 엔드포인트입니다.
#     """
#     return estest(request_message.user_query)
#     #return icebreakingnews()
#     #return "10.아이스브레이킹용 기사조회"


# @router.post("/es_test")
# async def es_test(chat_request: ChatRequest):

#     # Pydantic을 사용해 자동으로 JSON 파싱
#     #request_message = chat_request.request_message
#     # print("request_message:", request_message)
#     """
#     10.아이스브레이킹용 기사조회 엔드포인트입니다.
#     """

#     from elasticsearch import Elasticsearch

#     es = Elasticsearch("https://10.235.101.166:19200",
#                         ca_certs='ca.crt',
#                         basic_auth = ("elastic","o5f6kavqQTgWeOrdcY18")
#                         ,verify_certs=False )  # 엘라스틱서치 URL

#     sResult = None
#     if es.ping():
#         sResult = "엘라스틱서치 연결완료"
#     else:
#         sResult = "엘라스틱서치 연결실패"

#     return sResult
    
#     #return bgem3test(request_message.user_query)
#     #return icebreakingnews()
#     #return "10.아이스브레이킹용 기사조회"


# @router.post("/es_test1")
# async def es_test1(chat_request: ChatRequest):

#     # Pydantic을 사용해 자동으로 JSON 파싱
#     #request_message = chat_request.request_message
#     # print("request_message:", request_message)
#     """
#     10.아이스브레이킹용 기사조회 엔드포인트입니다.
#     """

#     search_instance = SearchQuery(index="tbl_lparag0200")

#     # 평문 + 덴스 벡터 검색 및 리랭크
#     results = search_instance.search_and_rerank("골다공증")
    
#     # print("리랭크된 검색 결과:")
#     # for result in results:
#     #     print(result['_source'])

    
#     return results

# @router.post("/es_test2")
# async def es_test2(chat_request: ChatRequest):

#     # Pydantic을 사용해 자동으로 JSON 파싱
#     #request_message = chat_request.request_message
#     # print("request_message:", request_message)
#     """
#     10.아이스브레이킹용 기사조회 엔드포인트입니다.
#     """

#     from elasticsearch import Elasticsearch

#     es = Elasticsearch("http://10.235.184.166:19200",basic_auth = ("elastic","u493xlK7VUYpXRaeipgj"),verify_certs=False)  # 엘라스틱서치 URL

#     sResult = None
#     if es.ping():
#         sResult = "엘라스틱서치 연결완료"
#     else:
#         sResult = "엘라스틱서치 연결실패"

#     return sResult
    
#     #return bgem3test(request_message.user_query)
#     #return icebreakingnews()
#     #return "10.아이스브레이킹용 기사조회"



@router.post("/bgem3_return")
async def bgem3_return(chat_request1: ChatRequest1):

    # Pydantic을 사용해 자동으로 JSON 파싱
    #request_message = chat_request.request_message
    # print("request_message:", request_message)
    """
    단어을 넣으면 BGE-M3 벡터를 반환하는 엔드포인트입니다.
    이후 벡터로 엘라스틱서치 벡터검색 테스트가 가능합니다. 1024차원
    """
    request_message = chat_request1.request_message1

    user_query = [request_message.user_query]

    import requests
    import json

    #data = ["Hello world"]

    # BGE-m3 API 엔드포인트
    BGE_API_URL = "http://hli-ait-emb-be-svc-active.hli-ait-ns-emb.svc.cluster.local/embedding/dense_vector"  # BGE-m3 API URL
    response = requests.post(BGE_API_URL,headers={"accept": "application/json", "Content-Type":"application/json"},data = json.dumps(user_query))
    sResult = None
    if response.status_code == 200:
        sResult = response.json()
    else:
        sResult = response.text

    return sResult
    
# @router.post("/bgem3_insert")
# async def bgem3_insert(chat_request: ChatRequest):

#     # Pydantic을 사용해 자동으로 JSON 파싱
#     #request_message = chat_request.request_message
#     # print("request_message:", request_message)
#     """
#     10.아이스브레이킹용 기사조회 엔드포인트입니다.
#     """
#     return insert_data()

