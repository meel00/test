from azure.identity import DefaultAzureCredential, get_bearer_token_provider, ManagedIdentityCredential
from openai import AzureOpenAI
import openai
import time
#from azure.openai import OpenAIClient

# JSON을 파싱하고 특정 id의 prompt를 찾는 함수
def jsonparse(target_id):
    parsed_data = json.loads(prompts.prompt_63)  # Assuming prompts.prompt_63 is a valid JSON string
    for prompt in parsed_data["prompts"]:
        if prompt["id"] == target_id:
            return prompt
    return None  # 해당 id가 없을 경우 None 반환


# LLM 호출 및 결과 출력
def json_to_string(json_object):
    """
    JSON 객체를 문자열로 변환하는 함수

    Parameters:
    json_object (dict): 변환할 JSON 객체

    Returns:
    str: JSON 문자열
    """
    return json.dumps(json_object, ensure_ascii=False, indent=4)

def aoaitest(data = "영국의 수도은 어디인가?"):
    prompt = data
   
    credentials = ManagedIdentityCredential(client_id = "8aabda8b-5ded-4179-99d5-6b3bc831af91")
    azure_endpoint = "https://hliazraitaoaiptu.openai.azure.com/" 
    deployment_name="hliazraitaoai-gpt4o"

    #openai.api_type="azure"
    openai.azure_endpoint = azure_endpoint
    openai.api_version = "2024-08-01-preview"
    openai.api_key = credentials.get_token("https://cognitiveservices.azure.com/").token
    
        # LLM을 호출하여 응답 생성
    response = openai.chat.completions.create(
        model=deployment_name,
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": data}
        ]
    )
    print("######################## 4 ")
    print(response)
    return response


def aoaitest_10k(data = "영국의 수도은 어디인가?"):
    start_time = time.time()
    prompt = data
    
    data = "가나다라마바사고고고" * 1500
    credentials = ManagedIdentityCredential(client_id = "8aabda8b-5ded-4179-99d5-6b3bc831af91")
    azure_endpoint = "https://hliazraitaoaiptu.openai.azure.com/" 
    deployment_name="hliazraitaoai-gpt4o"

    #openai.api_type="azure"
    openai.azure_endpoint = azure_endpoint
    openai.api_version = "2024-08-01-preview"
    openai.api_key = credentials.get_token("https://cognitiveservices.azure.com/").token
    
        # LLM을 호출하여 응답 생성
    response = openai.chat.completions.create(
        model=deployment_name,
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": data}
        ]
    )

    end_time = time.time()
    elapsed_time = end_time -start_time
    start_time =time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(start_time))
    end_time =time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(end_time))

    
    oresult = "start : " + str(start_time) + "===>" + "end :" + str(end_time) + "===>" + "elapsed :" + str(elapsed_time)
    print(response , oresult)
    return response , oresult

def aoaitest_20k(data = "영국의 수도은 어디인가?"):
    start_time = time.time()
    prompt = data
    data = "가나다라마바사고고고" * 3000
    credentials = ManagedIdentityCredential(client_id = "8aabda8b-5ded-4179-99d5-6b3bc831af91")
    azure_endpoint = "https://hliazraitaoaiptu.openai.azure.com/" 
    deployment_name="hliazraitaoai-gpt4o"

    #openai.api_type="azure"
    openai.azure_endpoint = azure_endpoint
    openai.api_version = "2024-08-01-preview"
    openai.api_key = credentials.get_token("https://cognitiveservices.azure.com/").token
    
        # LLM을 호출하여 응답 생성
    response = openai.chat.completions.create(
        model=deployment_name,
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": data}
        ]
    )
    end_time = time.time()
    elapsed_time = end_time -start_time
    start_time =time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(start_time))
    end_time =time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(end_time))

    
    oresult = "start : " + str(start_time) + "===>" + "end :" + str(end_time) + "===>" + "elapsed :" + str(elapsed_time)
    print(response , oresult)
    return response , oresult

def aoaitest1(data):
    prompt = data
   
    credentials = ManagedIdentityCredential(client_id = "8aabda8b-5ded-4179-99d5-6b3bc831af91")
    azure_endpoint = "https://hliazraitaoaiptu.openai.azure.com/" 
    deployment_name="hliazraitaoai-gpt4o"

    #openai.api_type="azure"
    openai.azure_endpoint=azure_endpoint
    openai.api_version = "2024-08-01-preview"
    openai.api_key = credentials.get_token("https://cognitiveservices.azure.com/").token
    
        # LLM을 호출하여 응답 생성
    response = openai.chat.completions.create(
        model=deployment_name,
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": data}
        ]
    )
    print("######################## 4 ")
    print(response)
    return response

def aoaitest2(data):
    prompt = data
   
    credentials = ManagedIdentityCredential(client_id = "8aabda8b-5ded-4179-99d5-6b3bc831af91")
    azure_endpoint = "https://hliazraitaoaiptu.openai.azure.com" 
    deployment_name="hliazraitaoai-gpt4o"
    token_provider = get_bearer_token_provider(
        credentials, "https://cognitiveservices.azure.com/.default"
    )
    print("######################## 1 ")
    # Fetch and print the token
    token = token_provider()
    print("""token_provider = get_bearer_token_provider(
        credentials, "https://cognitiveservices.azure.com/.default"
    ) """)
    # print("token :",token)

    #openai_client = OpenAIClient(endpoint = azure_endpoint,credential = credentials)

    llm = AzureOpenAI(
        api_version="2024-08-01-preview",
        azure_endpoint= azure_endpoint,
        azure_ad_token_provider=token_provider
    )

    
    # llm = OpenAIClient(
    #     api_version="2024-06-01",
    #     azure_endpoint= azure_endpoint,
    #     credential = credentials
    #     # azure_ad_token_provider=token_provider
    # )

    print("######################## 3 ")


    # LLM을 호출하여 응답 생성
    response = llm.chat.completions.create(
        temperature=0.5, 
        model=deployment_name,
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": data}
        ]
    )
    print("######################## 4 ")
    print(response)
    return response

def aoaitest3(data = "영국의 수도은 어디인가?"):
    prompt = data
   
    credentials = ManagedIdentityCredential(client_id = "8aabda8b-5ded-4179-99d5-6b3bc831af91")
    azure_endpoint = "https://hliazraitaoaiptu.openai.azure.com" 
    deployment_name="hliazraitaoai-gpt4o"
    token_provider = get_bearer_token_provider(
        credentials, "https://cognitiveservices.azure.com/.default"
    )
    print("######################## 1 ")
    # Fetch and print the token
    token = token_provider()
    print("""token_provider = get_bearer_token_provider(
        credentials, "https://cognitiveservices.azure.com/.default"
    ) """)
    # print("token :",token)

    #openai_client = OpenAIClient(endpoint = azure_endpoint,credential = credentials)

    llm = AzureOpenAI(
        api_version="2024-08-01-preview",
        azure_endpoint= azure_endpoint,
        azure_ad_token_provider=token_provider
    )

    
    # llm = OpenAIClient(
    #     api_version="2024-06-01",
    #     azure_endpoint= azure_endpoint,
    #     credential = credentials
    #     # azure_ad_token_provider=token_provider
    # )

    print("######################## 3 ")


    # LLM을 호출하여 응답 생성
    response = llm.chat.completions.create(
        temperature=0.5, 
        model=deployment_name,
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": data}
        ]
    )
    print("######################## 4 ")
    print(response)
    #return response.choices[0].message.content
    return response