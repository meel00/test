from src.utils.db_helper import *

def get_prduct_info(strProductname):
    mysqlHelper = MySQLHelper()
    mysqlHelper.connect()

    query = "select RCMD_PROD_FTUR_CNTN from tbl_aitcnvvc09 WHERE RCMD_PROD_NM = %(strProductname)s"
    param = {"strProductname": strProductname}
    oResult = mysqlHelper.select_query(query,param)

    if oResult == []:
        oResult = """- 고객이 예전에 건강보험에 가입했다면 암 주요치료비, 비갱신 입원, 수술, 비갱신 간병, 비갱신 질병 후유장해를 10년 이내 입원, 수술 이력이 없으면 비갱신으로 저렴한 보험료로 가입가능
- 간병인 보장은 비갱신형이면서 저렴한 보험료로 가입이 가능하고 타사 합산 최대 50만원까지 가입가능
- 가족력, 고혈압, 당뇨 등 건강이 걱정이신 분들도 일부보장 제외하고 면책이나 감액없이 바로 보장 가능 "	"- 혈전용해치료보장 3,000만원까지 확대
- 상급종합병원 질병재해수술 II특약 100만원까지 보장 확대 
- 2-3인실 입원시 상급종합병원 25만원, 종합병원 20만원까지 보장 확대"""
    return oResult


def get_fewshot(spch_type= "FR02",gpt_type = "GPT02"):
    mysqlHelper = MySQLHelper()
    mysqlHelper.connect()

    query = """select t2.spch_sntc_cntn 
               from tbl_aitsflsp01 t1
               join tbl_aitsflsp02 t2
               on t1.aist_spch_id = t2.aist_spch_id
               where 1=1
               and t1.use_yn = 'Y'
               and t1.aist_spch_prvn_dvsn_code =  %(spch_type)s
               and t1.aist_gpt_spch_cret_dvsn_code =  %(gpt_type)s
               order by rand()
               LIMIT 2
            """
    param = {"spch_type": spch_type,"gpt_type": gpt_type }
    oResult = mysqlHelper.select_query(query,param)
    return oResult


def get_query(request_message):
    user_query = request_message.user_query
    mysqlHelper = MySQLHelper()
    mysqlHelper.connect()
    oResult = mysqlHelper.select_query(user_query,None)
    return oResult


