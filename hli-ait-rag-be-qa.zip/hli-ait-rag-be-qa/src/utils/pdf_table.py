import pdfplumber
import requests
import json

def extract_text_and_tables(pdf_path):
    text = ""
    tables = []
    
    # PDF 파일 열기
    with pdfplumber.open(pdf_path) as pdf:
        # PDF의 모든 페이지를 순차적으로 처리
        for page_num in range(len(pdf.pages)):
            page = pdf.pages[page_num]
            
            # Page 번호가 8 또는 9일 때만 출력 (0-based indexing)
            #if page_num == 2 or page_num == 7:  # 실제로 8, 9 페이지에 해당하는 인덱스는 7, 8
            if page_num > 0 : #or page_num == 7:  # 실제로 8, 9 페이지에 해당하는 인덱스는 7, 8
                # 페이지 번호 출력
                print(f"Processing page: {page_num + 1}")
                
                # 텍스트 추출
                page_text = page.extract_text()
                if page_text:
                    # 페이지 구분자를 텍스트에 추가
                    text += f"\n--- Page {page_num + 1} ---\n"
                    text += page_text + "\n"
                
                # 표 추출
                page_tables = page.extract_tables()
                for table in page_tables:
                    if table:
                        # 페이지 구분자를 각 테이블 앞에 추가
                        tables.append(f"--- Page {page_num + 1} ---")
                        # 각 표를 리스트로 변환하여 저장 (첫 행을 헤더로 사용)
                        tables.append([dict(zip(table[0], row)) for row in table[1:]])

    return text, tables


# LLM API 호출 함수
def call_llm_api(prompt):
    import openai

    # Set up your OpenAI API key
    #openai.api_key = 'your-api-key'

    # Call the API
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "user", "content": prompt},
        ],
        temperature = 0
    )

    print("*" *100 )
    print(response.choices[0].message['content'])
    # 질의내용
    #prompt = "대한민국의 수도는 어디인가요?"

    # 질의
    #print(f"[답변]: {chat_completion.invoke(prompt)}")

    # api_url = "https://api.example.com/llm"  # LLM API URL
    # headers = {
    #     "Content-Type": "application/json",
    #     "Authorization": "Bearer YOUR_API_KEY"  # API 키 입력
    # }
    # payload = {
    #     "prompt": prompt,
    #     "max_tokens": 150  # 원하는 최대 토큰 수
    # }
    # response = requests.post(api_url, headers=headers, data=json.dumps(payload))
    # return response.json()

# 메인 함수
def main():
    # 상품제안서 PDF 경로
    pdf_path = "한화생명 시그니처 암치료비보험 무배당_상품설명서.pdf"

    # PDF에서 텍스트와 표 데이터 추출
    text, tables = extract_text_and_tables(pdf_path)

    print(text)
    print(tables)

    # 프롬프트 생성
    prompt = f"""
    요청: 아래에 제공되는 **내용**과 **표 데이터**를 기반으로 ***해약환급금**** 대해 알려줘 . 답은 내가 보낸 문서를 기반으로 답하고 출처는 --- Page x--- 모양을 가져다죠. --- Page x---는 문장의 앞부분에 있는 것이 맞아
    **내용** : {text}
    **표 데이터** : {json.dumps(tables, ensure_ascii=False)}
    """

    # LLM API 호출
    result = call_llm_api(prompt)
    
    # # 결과 출력
    # print("LLM 응답:", result)

if __name__ == "__main__":
    main()
