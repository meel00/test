import random
from typing import List,Dict
from typing import Optional
from src.utils import pdf_table,prompts
from azure.identity import DefaultAzureCredential, get_bearer_token_provider, ManagedIdentityCredential
# from openai import AzureOpenAI
# import openai
import os
import json

#from langchain_openai import AzureChatOpenAI
#from langchain.chat_models import ChatOpenAI#,AzureChatOpenAI
from langchain.schema import HumanMessage,SystemMessage
from src.common.logging.logger import LOGGER
import time
from langchain.callbacks.base import BaseCallbackHandler

from langchain_community.chat_models import ChatOpenAI,AzureChatOpenAI
# from langchain.utils.retry import get_retry_decorator

from langchain_core.messages.base import BaseMessage
from langchain_core.messages.system import SystemMessage
from langchain_core.messages.human import HumanMessage


class TokenStreamHandler(BaseCallbackHandler):
    def __init__(self):
        self.start_time = None
        self.first_token_time = None
        self.last_token_time = None

    def on_llm_start(self,serialized: dict ,prompts:list[str] ,**kwargs):
        self.start_time =time.time()


    def on_llm_new_token(self,token: str , **kwargs):
        current_time = time.time()

        if self.first_token_time is None:
            self.first_token_time = current_time - self.start_time

        self.last_token_time = current_time - self.start_time

        print(token , end = "")

    def on_llm_end(self,response ,**kwargs):
        if self.last_token_time:
            total_duration = self.last_token_time - self.first_token_time
            LOGGER.debug("#" * 70)
            LOGGER.debug(f"First response time: {self.first_token_time:.2f} seconds")
            LOGGER.debug(f"Total response time: {total_duration:.2f} seconds")
            LOGGER.debug("#" * 70)

    def get_timings(self,start_time):
        total_time = self.last_token_time - start_time
        first_token_time = self.first_token_time - start_time

        return first_token_time, total_time


class AOAIHelper:
    def __init__(self):
        #############################################################################################
        credentials = ManagedIdentityCredential(client_id = "8aabda8b-5ded-4179-99d5-6b3bc831af91")
        self.azure_endpoint = "https://hliazraitaoaiptu.openai.azure.com/" 
        self.deployment_name="hliazraitaoai-gpt4o"
        self.openai_api_version = "2024-08-01-preview"

        try:
            self.api_key = credentials.get_token("https://cognitiveservices.azure.com/").token
        except:
            self.api_key = "21"

        self.handler =  TokenStreamHandler()

        self.openai = AzureChatOpenAI(
            azure_deployment = self.deployment_name,
            openai_api_version= self.openai_api_version,
            azure_endpoint = self.azure_endpoint,
            openai_api_key = self.api_key,
            callbacks = [self.handler],
            #streaming=True
            # temperature = temperature,
        )

        self.chatopenai = ChatOpenAI(
            #azure_deployment = self.deployment_name,
            #openai_api_version= self.openai_api_version,
            azure_endpoint = self.azure_endpoint,
            openai_api_key = self.api_key,
            streaming=True
            # temperature = temperature,
        )


        ##############################################################################################
    # retry_decorator = get_retry_decorator(max_attempts = 5,wait_min= 1,wait_max =10 )
    # @retry_decorator
    def get_generate_text_response(self, prompt, temperature: float = 0.7):
        """
        주어진 프롬프트로 텍스트 생성
        """

        def extract_content(messages):
            if isinstance(messages, list):
                return " ".join(
                    [msg.content if isinstance(msg, (HumanMessage, SystemMessage)) else str(msg) for msg in messages]
                )
            elif isinstance(messages, BaseMessage):
                return messages.content
            else:
                return str(messages)

        prompt_ = extract_content(prompt)

        response = None
        try:
            response = self.openai.invoke(prompt_,temperature =temperature )
        except:
            try:
                response = self.openai.invoke(prompt_,temperature =temperature )
            except:
                response = self.openai.invoke(prompt_,temperature =temperature )

        LOGGER.debug(response)
        return response


    # retry_decorator = get_retry_decorator(max_attempts = 5,wait_min= 1,wait_max =10 )
    # @retry_decorator
    def get_generate_text_response_(self, prompt: str, max_tokens: int = 100, temperature: float = 0.7):
        """
        주어진 프롬프트로 텍스트 생성
        """

                # 응답 시간 측정 함수
        def measure_response_times(prompt: str,temperature: float = 0.7):
            start_time = time.time()

            handler =  TokenStreamHandler()

            # 요청 보내기
            response = self.openai(
                messages = prompt,
                #messages = [HumanMessage(content= prompt)],
                callbacks=[handler],
                #temperature = temperature
            )

            # 응답 시간 계산
            
            first_response_time ,total_duration = handler.get_timings(start_time)

            LOGGER.debug("#" * 70)
            LOGGER.debug(f"First response time: {first_response_time:.2f} seconds")
            LOGGER.debug(f"Total response time: {total_duration:.2f} seconds")
            LOGGER.debug("#" * 70)
            # print(f"First response time: {first_response_time:.2f} seconds")
            # print(f"Total response time: {total_duration:.2f} seconds")
            return response
        
        response = None
        try:
            response = measure_response_times(prompt,temperature =temperature )
        except:
            try:
                response = measure_response_times(prompt,temperature =temperature )
            except:
                response = measure_response_times(prompt,temperature =temperature )

        LOGGER.debug(response)
        return response.content

    #@retry_decorator
    def get_chat_response(self, prompt: str, max_tokens: int = 100, temperature: float = 0.7):
        """
        주어진 프롬프트로 텍스트 생성
        """
        response = self.chatopenai.invoke(prompt,temperature =temperature )

        return response.content


    # def generate_text(self, prompt: str, max_tokens: int = 100, temperature: float = 0.7):
    #     """
    #     주어진 프롬프트로 텍스트 생성

    #     :param prompt: 생성할 텍스트의 프롬프트
    #     :param max_tokens: 생성할 최대 토큰 수
    #     :param temperature: 텍스트 생성의 다양성(높을수록 다양하게 생성)
    #     :return: 생성된 텍스트
    #     """
    #     response = openai.chat.completions.create(
    #         model=self.deployment_name,
    #         messages=[
    #         {"role": "system", "content": "You are a helpful assistant."},
    #         {"role": "user", "content": prompt}
    #     ]
    #     )
    #     return response



        # try:
        #     response = openai.Completion.create(
        #         engine=self.deployment_name,
        #         prompt=prompt,
        #         max_tokens=max_tokens,
        #         temperature=temperature
        #     )
        #     return response['choices'][0]['text'].strip()
        # except Exception as e:
        #     print(f"Error generating text: {e}")
        #     return None

    # def chat(self, messages, max_tokens: int = 100, temperature: float = 0.7):
    #     """
    #     ChatGPT 스타일의 대화 생성

    #     :param messages: 대화 메시지 리스트 [{'role': 'user', 'content': '...'}]
    #     :param max_tokens: 생성할 최대 토큰 수
    #     :param temperature: 텍스트 생성의 다양성
    #     :return: AI 응답 메시지
    #     """
    #     try:
    #         response = openai.ChatCompletion.create(
    #             engine=self.deployment_name,
    #             messages=messages,
    #             max_tokens=max_tokens,
    #             temperature=temperature
    #         )
    #         return response['choices'][0]['message']['content'].strip()
    #     except Exception as e:
    #         print(f"Error in chat completion: {e}")
    #         return None


    # JSON을 파싱하고 특정 id의 prompt를 찾는 함수
    def get_prompt_by_id(self,target_id):
        #parsed_data = json.loads(prompts.prompt_63)  # Assuming prompts.prompt_63 is a valid JSON string
        parsed_data = prompts.prompt_63  # Assuming prompts.prompt_63 is a valid JSON string
        for prompt in parsed_data["prompts"]:
            if prompt["id"] == target_id:
                return prompt
        return None  # 해당 id가 없을 경우 None 반환






