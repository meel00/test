
import json

 # 나이대 정규화
def get_age_group(age):
    try:
        age= age.replace("세",'')
        age= age.replace("살",'')
        age = int(age)
    except:
        age = age[:2]
        age = int(age)

    age_group = (age//10) * 10
    return f"{age_group}대"

# 성별 정규화
def get_gender(gender):
    sex ="여성"
    if gender in ("남성","남자","Male","male","Man","man"):
        sex =  "남성"
    return sex



    # LLM 호출 및 결과 출력
def json_to_string(json_object):
    """
    JSON 객체를 문자열로 변환하는 함수

    Parameters:
    json_object (dict): 변환할 JSON 객체

    Returns:
    str: JSON 문자열
    """
    return json.dumps(json_object, ensure_ascii=False, indent=4)