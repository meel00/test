import mysql.connector
from mysql.connector import Error

class MySQLHelper:
    def __init__(self):
        self.connection =None
        self.host = "hliazrqaitmysql.mysql.database.azure.com"
        self.username = "RAGASV"
        self.password = "!Rdmddyd11"
        #self.database = "qait"
        self.database = "aa_test"
        self.port = 3306

    def connect(self):
        self.connection = mysql.connector.connect(
            host= self.host ,
            user = self.username ,
            password = self.password,
            database = self.database,
            port = self.port
        )


    def select_query(self, query ,params=None):
        cursor = self.connection.cursor()
        cursor.execute(query,params)
        result = cursor.fetchall()
        return result



    # def connect(self):
    #     try:
    #         self.connection = mysql.connector.connect(
    #             host= self.host ,
    #             user = self.username ,
    #             password = self.password
    #         )
    #     except Error as e:
    #         print("connect_error",e)
    #         return None
    #     finally:
    #         self.connection =None


    # def select_query(self, query ,params=None):
    #     if self.connection is None:
    #         print("connection None")
    #         return
        
    #     cursor = self.connection.cursor()
    #     try:
    #         cursor.excute(query,params)
    #         result = cursor.fetchall()
    #         return result
    #     except Error as e:
    #         print("select_query_error",e)
    #         return None
    #     finally:
    #         cursor.close()


