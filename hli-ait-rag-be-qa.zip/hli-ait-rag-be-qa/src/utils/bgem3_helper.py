import requests
import json

def query_bge(text):
    #response = requests.post(BGE_API_URL, json={"text": text})
    # BGE-m3 API 엔드포인트
    embedded_vector = []
    BGE_API_URL = "http://hli-ait-emb-be-svc-active.hli-ait-ns-emb.svc.cluster.local/embedding/dense_vector"  # BGE-m3 API URL
    response = requests.post(BGE_API_URL,headers={"accept": "application/json", "Content-Type":"application/json"},data = json.dumps([text]))
    if response.status_code == 200:
        embedded_vector = response.json()
        embedded_vector = embedded_vector["embedded_vector"][0]
        return embedded_vector  # BGE-m3에서 반환된 벡터
    else:
        #raise Exception("BGE-m3 API 호출 실패: {}".format(response.text))
        return embedded_vector  # BGE-m3에서 반환된 벡터

    