import requests
try:
    from src.utils.elasticsearch_helper import *
except:
    from elasticsearch_helper import *
from src.utils.bgem3_helper import query_bge
from src.utils import pdf_table,prompts
import pandas as pd
import os
from src.utils.db_query import *
import json

# BM25검색 함
def get_ice_breaking_news(request_message):
    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    age = request_message.age
    gender = request_message.gender
    career_field = request_message.career_field
    product_name = request_message.product_name
    product_tag = request_message.product_tag
    #==================================

    # 나이대 정규화
    def get_age_group(age):
        try:
            age= age.replace("세",'')
            age= age.replace("살",'')
            age = int(age)
        except:
            age = age[:2]
            age = int(age)

        age_group = (age//10) * 10
        return f"{age_group}대"

    # 성별 정규화
    def get_gender(gender):
        sex ="여성"
        if gender in ("남성","남자","Male","male","Man","man"):
            sex =  "남성"
        return sex

    search_instance = ElasticsearchClient(index="tbl_lparag0200")

    #query = "건강보험 20대 남성"
    query = product_tag + " " + get_age_group(age) + " " + get_gender(gender) + " " + product_name
    return_fields = ["news_id","news_title","news_date","news_url"]
    search_query = {
        "_source": return_fields ,
        "query": {
                "bool": {
                "must": [
                    {
                        "match": {
                            "search_keyword": query
                        }
                    },
                    {
                        "range": {
                            "news_date": {
                            "gte": "now-90d/d",
                            "lt": "now/d"
                            }
                        }
                    }
                ]
                }
            },
            "collapse":{
                "field" : "news_url.keyword"
            }
        
    }
    results = search_instance.search(search_query,10)
    return results

def get_ice_breaking_news_rrf(request_message):
    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================

    age = request_message.age
    gender = request_message.gender
    career_field = request_message.career_field
    product_name = request_message.product_name
    product_tag = request_message.product_tag
    #==================================

    # 나이대 정규화
    def get_age_group(age):
        try:
            age= age.replace("세",'')
            age= age.replace("살",'')
            age = int(age)
        except:
            age = age[:2]
            age = int(age)

        age_group = (age//10) * 10
        return f"{age_group}대"

    # 성별 정규화
    def get_gender(gender):
        sex ="여성"
        if gender in ("남성","남자","Male","male","Man","man"):
            sex =  "남성"
        return sex

    search_instance = ElasticsearchClient(index="tbl_lparag0200")

    #query = "건강보험 20대 남성"
    query = product_tag + " " + get_age_group(age) + " " + get_gender(gender) + " " + product_name
    vector_query =  query_bge(product_tag)

    print("vector_query",vector_query)
    #vector_query = vector_query_[0]

    return_fields = ["news_title","news_content","news_date","news_url"]
    search_query = {
        "_source": return_fields ,
        "retriever": {
        "rrf": { 
            "retrievers": [
                {
                    "standard": { 
                        "query": {
                            "term": {
                                "news_content": query
                            }
                        }
                    }
                },
                {
                    "knn": { 
                        "field": "dense_vector",
                        "query_vector": vector_query ,
                        "k": 10,
                        "num_candidates": 20
                    }
                }
            ],
            "rank_window_size": 50,
            "rank_constant": 20
            }
        },
        "collapse":{
            "field" : "_id"
        }
    }

    results = search_instance.search(search_query,10)
    return results


def get_ice_breaking_news_rrf_unique(request_message):
    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================

    age = request_message.age
    gender = request_message.gender
    career_field = request_message.career_field
    product_name = request_message.product_name
    product_tag = request_message.product_tag
    #==================================

    # 나이대 정규화
    def get_age_group(age):
        try:
            age= age.replace("세",'')
            age= age.replace("살",'')
            age = int(age)
        except:
            age = age[:2]
            age = int(age)

        age_group = (age//10) * 10
        return f"{age_group}대"

    # 성별 정규화
    def get_gender(gender):
        sex ="여성"
        if gender in ("남성","남자","Male","male","Man","man"):
            sex =  "남성"
        return sex

    search_instance = ElasticsearchClient(index="tbl_lparag0200")

    #query = "건강보험 20대 남성"
    query = product_tag + " " + get_age_group(age) + " " + get_gender(gender) + " " + product_name
    vector_query =  query_bge(product_tag)

    print("vector_query",vector_query)
    #vector_query = vector_query_[0]

    return_fields = ["news_id","news_title","news_content","news_date","news_url"]
    search_query = {
        "_source": return_fields ,
        "retriever": {
        "rrf": { 
            "retrievers": [
                {
                    "standard": { 
                        "query": {
                            "term": {
                                "news_content": query
                            }
                        }
                    }
                },
                {
                    "knn": { 
                        "field": "dense_vector",
                        "query_vector": vector_query ,
                        "k": 30,
                        "num_candidates": 50
                    }
                }
            ],
            "rank_window_size": 50,
            "rank_constant": 50
            }
        }
    }

    results = search_instance.search(search_query,30)

    data = [hit["_source"] for hit in results ]

    df = pd.DataFrame(data)
    unique_df = df.drop_duplicates(subset = ["news_url"])
    unique_df_10 =unique_df.head(10)

    es_format = [
                    {
                        "_source":{
                            "news_id":row["news_id"],
                            "news_title":row["news_title"],
                            "news_date":row["news_date"],
                            "news_url":row["news_url"]
                        }
                    }
                    for _,row in unique_df_10.iterrows()
    ]

    # final_result= {
    #     "hits" :{
    #         "hits": es_format
    #     }
    # }


    return es_format



def get_ice_breaking_news_rrf_temp(request_message):
    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================

    age = request_message.age
    gender = request_message.gender
    career_field = request_message.career_field
    product_name = request_message.product_name
    product_tag = request_message.product_tag
    #==================================

    # 나이대 정규화
    def get_age_group(age):
        try:
            age= age.replace("세",'')
            age= age.replace("살",'')
            age = int(age)
        except:
            age = age[:2]
            age = int(age)

        age_group = (age//10) * 10
        return f"{age_group}대"

    # 성별 정규화
    def get_gender(gender):
        sex ="여성"
        if gender in ("남성","남자","Male","male","Man","man"):
            sex =  "남성"
        return sex

    search_instance = ElasticsearchClient(index="bgem3_dummy2")

    #query = "건강보험 20대 남성"
    query = product_tag + " " + get_age_group(age) + " " + get_gender(gender) + " " + product_name
    vector_query =  query_bge(product_tag)

    print("vector_query",vector_query)
    #vector_query = vector_query_[0]

    return_fields = ["newsTitle","newsContext","RegisterDateTime","newsOriginUrl"]
    search_query = {
        "_source": return_fields ,
        "retriever": {
        "rrf": { 
            "retrievers": [
                {
                    "standard": { 
                        "query": {
                            "term": {
                                "news_content": query
                            }
                        }
                    }
                },
                {
                    "knn": { 
                        "field": "denseVector",
                        "query_vector": vector_query ,
                        "k": 10,
                        "num_candidates": 20
                    }
                }
            ],
            "rank_window_size": 50,
            "rank_constant": 20
            }
        }
    }

    results = search_instance.search(search_query,10)
    return results



def get_weather_news():
    """
    가장 최근 날씨 뉴스를 가져온다 1개 
    """
    search_instance = ElasticsearchClient(index="tbl_lparag0201")

    #query = "건강보험 20대 남성"
    return_fields = ["news_content"]
    search_query = {
        "_source": return_fields ,
        #"size": 1 ,
        "sort": [
        {"news_date": {"order" : "desc"}}
        ]    
    }
    results = search_instance.search(search_query,1)

    print(results)
    return results[0]["_source"]["news_content"]

def get_news_by_id(news_id):
    """
    뉴스아이디로 뉴스를 가져온다 1개 
    """
    search_instance = ElasticsearchClient(index="tbl_lparag0200")

    return_fields = ["news_content","news_url"]
    search_query = {
        "_source": return_fields ,
        "query": {
                "bool": {
                "must": [
                    {
                        "match": {
                            "news_id": news_id
                        }
                    },
                ]
                }
            },
            "collapse":{
                "field" : "news_url.keyword"
            }
        
    }
    results = search_instance.search(search_query,1)
    
    news = ""
    news_url = ""

    try:
        news = results[0]["_source"]["news_content"]
        news_url = results[0]["_source"]["news_url"]
    except:
        print("뉴스 에러")

    #print(results)
    return news,news_url


def get_news_by_random():
    """
    뉴스를  랜덤하개 1개 가져온다
    """
    search_instance = ElasticsearchClient(index="tbl_lparag0200")

    return_fields = ["news_id","news_url","news_content"]
    search_query = {
        "_source": return_fields ,
        "query": {
                "bool": {
                "must": [
                    {
                       "function_score": {
                        "functions": [
                          {
                            "random_score": {
                            }
                          }
                        ],
                        "boost_mode": "replace"
                      }
                    },
                    {
                        "range": {
                            "news_date": {
                            "gte": "now-95d/d",
                            "lt": "now/d"
                            }
                        }
                    }
                ]
                }
            }
        
    }
    results = search_instance.search(search_query,1)

    news = ""
    news_id = ""
    news_url = ""

    try:
        news = results[0]["_source"]["news_content"]
        news_id = results[0]["_source"]["news_id"]
        news_url = results[0]["_source"]["news_url"]
    except:
        print("랜덤뉴스 에러")

    return news,news_id,news_url

def get_productproposal_based_qna_source(request_message):
    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    proposal_number = request_message.proposal_number
    user_query = request_message.user_query
    product_name = request_message.product_name
    #==================================

    search_instance = ElasticsearchClient(index="tbl_lparag0200")

    vector_query =  query_bge(user_query)

    print("vector_query",vector_query)
    #vector_query = vector_query_[0]

    return_fields = ["news_title","news_content","news_date","news_url"]
    search_query = {
        "_source": return_fields ,
        "retriever": {
        "rrf": { 
            "retrievers": [
                {
                    "standard": { 
                        "query": {
                            "term": {
                                "news_content": user_query
                            }
                        }
                    }
                },
                {
                    "knn": { 
                        "field": "dense_vector",
                        "query_vector": vector_query ,
                        "k": 10,
                        "num_candidates": 20
                    }
                }
            ],
            "rank_window_size": 50,
            "rank_constant": 20
            }
        }
        # "collapse":{
        #     "field" : "_id"
        # }
    }

    results = search_instance.search(search_query,10)
    return results


def get_productproposal_based_qna_source_pdf(request_message):
    # 임시로 pdf에서 가져온다
    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    proposal_number = request_message.proposal_number
    user_query = request_message.user_query
    product_name = request_message.product_name
    #==================================
    domain_ = get_prduct_info(product_name)


    # 상품제안서 PDF 경로
    pdf_path = os.path.join(os.path.dirname(__file__),"product_doc.pdf")

    # PDF에서 텍스트와 표 데이터 추출
    text_, tables_ = pdf_table.extract_text_and_tables(pdf_path)

    domain = f"""
    **제안서 내용** : {text_}
    **제안서 표 데이터** : {json.dumps(tables_, ensure_ascii=False)}
    **상품특징** : {domain_}
    """
    return domain



def get_glossary_based_qna_source(request_message):
    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    user_query = request_message.user_query
    #==================================

    search_instance = ElasticsearchClient(index="tbl_lparag0200")

    vector_query =  query_bge(user_query)

    print("vector_query",vector_query)
    #vector_query = vector_query_[0]

    return_fields = ["news_title","news_content","news_date","news_url"]
    search_query = {
        "_source": return_fields ,
        "retriever": {
        "rrf": { 
            "retrievers": [
                {
                    "standard": { 
                        "query": {
                            "term": {
                                "news_content": user_query
                            }
                        }
                    }
                },
                {
                    "knn": { 
                        "field": "dense_vector",
                        "query_vector": vector_query ,
                        "k": 10,
                        "num_candidates": 20
                    }
                }
            ],
            "rank_window_size": 50,
            "rank_constant": 20
            }
        }
        # "collapse":{
        #     "field" : "_id"
        # }
    }

    results = search_instance.search(search_query,10)
    return results


def get_rate_based_qna_source(request_message):
    # 입력 파라미터
    fp_id = request_message.fp_id
    menu_id = request_message.menu_id
    #==================================
    user_query = request_message.user_query
    #==================================

    search_instance = ElasticsearchClient(index="tbl_lparag0200")

    vector_query =  query_bge(user_query)

    print("vector_query",vector_query)
    #vector_query = vector_query_[0]

    return_fields = ["news_title","news_content","news_date","news_url"]
    search_query = {
        "_source": return_fields ,
        "retriever": {
        "rrf": { 
            "retrievers": [
                {
                    "standard": { 
                        "query": {
                            "term": {
                                "news_content": user_query
                            }
                        }
                    }
                },
                {
                    "knn": { 
                        "field": "dense_vector",
                        "query_vector": vector_query ,
                        "k": 10,
                        "num_candidates": 20
                    }
                }
            ],
            "rank_window_size": 50,
            "rank_constant": 20
            }
        }
        # "collapse":{
        #     "field" : "_id"
        # }
    }

    results = search_instance.search(search_query,10)
    return results

