import requests
from elasticsearch import Elasticsearch

class ElasticsearchClient:

    def __init__(self, index):
        self.index = index
        self.client = Elasticsearch("https://10.235.101.166:19200",
                    ca_certs='ca.crt',
                    basic_auth = ("elastic","o5f6kavqQTgWeOrdcY18")
                    ,verify_certs=False )  # 엘라스틱서치 URL


    def search(self, query, size = 10):
        try:
            response = self.client.search(index=self.index, body=query, size = size)
            return response['hits']['hits']
        except Exception as e:
            print(f"Exception occured: {e}")
            return []


if __name__ == "__main__":
    #search_instance = SearchQuery(index="tbl_lparag0200")
    search_instance = ElasticsearchClient(index="bgem3_dummy2")
    # BM25 검색 후 KNN 리랭크
    query = "건강"
    return_fields = ["newsContext","newsTitle","RegisterDateTime","newsOriginUrl"]
    search_query = {
        "_source": return_fields ,
        "query": {
                "bool": {
                "must": [
                    {
                        "match": {
                            "newsContext": query
                        }
                    },
                    # {
                    #     "range": {
                    #         "RegisterDateTime": {

                    #         "gte": "now-27d/d",
                    #         "lt": "now/d"
                    #         }
                    #     }
                    # }
                ]
                }
            }
        
    }
    results = search_instance.search(search_query,3)
    # for result in results:
    #     print(result["_source"])
    print(results)


    search_instance = ElasticsearchClient(index="tbl_lparag0200")
    #search_instance = ElasticsearchClient(index="bgem3_dummy2")
    # BM25 검색 후 KNN 리랭크
    query = "건강"
    # return_fields = ["newsContext","newsTitle","RegisterDateTime","newsOriginUrl"]
    search_query = {
        #"_source": return_fields ,
        "query": {
                "bool": {
                "must": [
                    {
                        "match_all": {
                            
                        }
                    },
                    # {
                    #     "range": {
                    #         "RegisterDateTime": {

                    #         "gte": "now-27d/d",
                    #         "lt": "now/d"
                    #         }
                    #     }
                    # }
                ]
                }
            }
        
    }
    results = search_instance.search(search_query,3)
    # for result in results:
    #     print(result["_source"])
    print(results)
   
   